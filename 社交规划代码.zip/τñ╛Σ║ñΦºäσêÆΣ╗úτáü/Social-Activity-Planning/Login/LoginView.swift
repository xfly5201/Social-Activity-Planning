//
//  LoginView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/11/30.
//

import SwiftUI
import CoreData


enum AlertTypeLogin: Identifiable {
    case success, failure
    var id: Int {
        hashValue
    }
}

// 用户登录
struct LoginView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @EnvironmentObject var coreDataStack: CoreDataStack

    @State private var userName: String = ""
    @State private var password: String = ""
    @State private var isShow: Bool = false // 密码是否展示
    @State private var isAgree: Bool = false // 协议是否同意
    @State private var isLogin: Bool = false // 是否用户登录成功
    @State private var isLoginAdm: Bool = false // 是否管理员登录成功
    @State private var alertType: AlertTypeLogin?
    @State private var errorInfo: String = ""
    @State private var InfoCopy: String = ""
    @State private var loggedInUser: User?
    @State private var loggedInAdm: Admin?
    
    var body: some View {
        
        NavigationView{
            
            VStack{
                
                HStack{
                    Text("欢迎使用 社交规划助手")
                        .fontWeight(.bold)
                        .font(.title)
                        .padding(.top,90)
                        .padding(.horizontal,30)
                }
                
                HStack{
                    Text("用户登录")
                        .fontWeight(.medium)
                        .font(.title)
                        .padding(.top,50)
                        .padding(.horizontal,30)
                    Spacer()
                }
                
                HStack{
                    Text("用户名:")
                    TextField("请输入用户名", text: $userName)
                        .textFieldStyle(.roundedBorder)
                    Button(action: {
                        userName = ""
                        password = ""
                    }, label: {
                        Image(systemName: "delete.left")
                    })
                }
                .padding(.top)
                .padding(.horizontal)
                .buttonStyle(.automatic)
                
                
                HStack{
                    Text("密码:")
                    if isShow {
                        TextField("请输入密码", text: $password)
                            .textFieldStyle(.roundedBorder)
                            .padding(.leading,19)
                            
                    }
                    else{
                        SecureField("请输入密码", text: $password)
                            .textFieldStyle(.roundedBorder)
                            .padding(.leading,19)
                    }
                    
                    Button(action: {
                        isShow.toggle()
                    }, label: {
                        isShow ? Image(systemName: "eye") : Image(systemName: "eye.slash")
                    })
                }
                .buttonStyle(.automatic)
                .padding(.horizontal)
                .padding(.bottom)
                
                HStack{
                    
                    Button(action: {
                        isAgree.toggle()
                    }, label: {
                        isAgree ? Image(systemName: "circle.circle") : Image(systemName: "circle")
                    })
                    .padding(.leading)
                    
                    
                    Text("我已阅读并同意")
                    
                    NavigationLink{
                        ManualView()
                    }label: {
                        Text("用户手册")
                    }
                    
                    Text("和")
                    
                    NavigationLink{
                        PolicyView()
                    }label: {
                        Text("隐私政策")
                    }

                    
                    Spacer()
                }
                .font(.system(size: 15))
                .padding(.top)
                
            
                // 登录逻辑
                Button {
                    if login() {
                        alertType = .success
                    }
                    else {
                        InfoCopy=errorInfo
                        errorInfo=""
                        alertType = .failure
                    }
                    
                } label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.blue)
                            .frame(width: 300, height: 50)
                        Text("立即登录")
                            .foregroundColor(.white)
                        Spacer()
                    }
                }
                .padding(.top,50)
                .alert(item: $alertType) { alertType in
                    switch alertType {
                    case .success:
                        return Alert(title: Text("登录成功"), message: Text("欢迎使用社交规划助手"), dismissButton: .default(Text("好"), action: {
                            if userName.count>=6 && userName.count<=10 {
                                isLogin = true
                            }
                            else{
                                isLoginAdm = true
                            }
                                }))
                    case .failure:
                        return Alert(title: Text("登录失败"), message: Text(InfoCopy), dismissButton: .default(Text("好")))
                    }
                }
                
                NavigationLink(destination: MainView(user: loggedInUser), isActive: $isLogin) {
                    EmptyView()
                }
                
                NavigationLink(destination: AdmMainView(adm: loggedInAdm), isActive: $isLoginAdm) {
                    EmptyView()
                }
                
                Text("你还没账号？")
                    .padding(10)
                    .foregroundColor(.gray)
                
                NavigationLink{
                    RegisterView()
                }label: {
                    Text("立即注册");
                }
                
                Spacer()
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    func login() ->Bool{
        if !isAgree {
            errorInfo+="请先阅读并同意用户手册和隐私政策"
            return false
        }
        if userName.count>=6 && userName.count<=10 {
            let request: NSFetchRequest<User> = User.fetchRequest()
            request.predicate = NSPredicate(format: "name == %@ AND password == %@", userName, password)
            
            if let result = try? viewContext.fetch(request), !result.isEmpty {
                let user = result.first!
                let userIdString = user.userId?.uuidString
                UserDefaults.standard.set(userIdString, forKey: "loggedInUserId")
                loggedInUser = user
                return true
            } else {
                errorInfo += "用户名或密码错误，请重新输入"
                return false
            }
        }
        else {
            let request: NSFetchRequest<Admin> = Admin.fetchRequest()
            request.predicate = NSPredicate(format: "name == %@ AND password == %@", userName, password)
            
            if let result = try? viewContext.fetch(request), !result.isEmpty {
                let adm = result.first!
                let admIdString = adm.admId?.uuidString
                UserDefaults.standard.set(admIdString, forKey: "loggedInAdmId")
                loggedInAdm = adm
                return true
            } else {
                errorInfo += "用户名或密码错误，请重新输入"
                return false
            }
        }
    }
}


#Preview {
    LoginView()
}
