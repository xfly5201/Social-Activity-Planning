//
//  ManualView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/11/30.
//

import SwiftUI

// 用户手册
struct ManualView: View {
    @Environment(\.presentationMode) var presentationMode
    var policyText="""
                    社交活动规划助手是一款专为帮助您轻松规划和管理各种社交活动（如派对、聚会、会议等）设计的应用程序。它的主要功能包括活动创建、邀请管理、RSVP管理、活动日程安排、预算管理、任务分配、提醒通知、活动反馈收集，以及数据备份。

                    开始使用
                    安装和设置
                    从应用商店下载并安装“社交活动规划助手”。
                    打开应用程序，按照指示完成初始设置。（可选）连接到您的社交媒体账户，以便更容易分享活动。
                    活动创建
                    点击“创建新活动”。填写活动名称、日期、时间和地点。保存活动信息。
                    活动邀请
                    选择您的活动。点击“添加邀请”。输入或选择朋友、同事或家人的联系信息。通过好友列表发送邀请。
                    RSVP管理
                    在应用程序的“我的活动”部分查看RSVP回复。跟踪确认参加的嘉宾数量。
                    活动日程
                    选择特定活动。查看和编辑活动日程和安排。
                    预算管理
                    为您的活动设置预算。记录所有支出。
                    提醒和通知
                    设置活动前的提醒时间。系统将自动发送提醒给您和参与者。
                    数据备份
                    在设置中启用自动备份。确保所有数据都安全存储。

                """
    var body: some View {
        VStack {
            Text(policyText)
            Spacer()
        }
        .padding()
        .navigationBarBackButtonHidden(true) // 隐藏默认的返回按钮
        .navigationBarItems(leading: Button(action: {
            self.presentationMode.wrappedValue.dismiss() // 执行返回操作
        }) {
            HStack {
                Image(systemName: "arrow.left") // 可以自定义图标
                Text("返回") // 可以自定义文本
            }
        })
        .navigationTitle("用户手册")
    }
}

#Preview {
    ManualView()
}
