//
//  RegisterView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/11/30.
//

import SwiftUI

enum AlertType: Identifiable {
    case success, failure
    var id: Int {
        hashValue
    }
}

// 用户注册
struct RegisterView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.managedObjectContext) private var viewContext
    @State private var name: String = ""
    @State private var password1: String = ""
    @State private var password2: String = ""
    @State private var email: String = ""
    @State private var phoneNumber: String = ""
    @State private var erroInfo: String = ""
    @State private var InfoCopy: String = ""
    @State private var alertType: AlertType?
    @State private var isShow1: Bool=false
    @State private var isShow2: Bool=false
    
    @FetchRequest<User>(
        sortDescriptors: [
            NSSortDescriptor(keyPath: \User.name, ascending: true),
        ]
    )var users
    
    var body: some View {
        
        VStack {
            HStack{
                Text("用户名:")
                TextField("请输入用户名", text: $name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.leading,5)
            }.padding()
            
            HStack{
                Text("6到10个字母或数字")
                    .font(.system(size: 15))
                    .padding(.leading)
                    .foregroundColor(.gray)
                Spacer()
            }
            
            HStack{
                Text("密码:")
                
                if isShow1 {
                    TextField("请输入密码", text: $password1)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading,5)
                        
                }
                else{
                    SecureField("请输入密码", text: $password1)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading,5)
                }
                
                Button(action: {
                    isShow1.toggle()
                }, label: {
                    isShow1 ? Image(systemName: "eye") : Image(systemName: "eye.slash")
                })
            }.padding()
            
            
            
            HStack{
                Text("最少8个字符，至少1个大写字母、1个小写字母和1个数字")
                    .font(.system(size: 15))
                    .padding(.leading)
                    .foregroundColor(.gray)
                Spacer()
            }
            
            HStack{
                Text("确认密码:")
                if isShow2 {
                    TextField("请确认密码", text: $password2)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading,5)
                        
                }
                else{
                    SecureField("请确认密码", text: $password2)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading,5)
                }
                
                Button(action: {
                    isShow2.toggle()
                }, label: {
                    isShow2 ? Image(systemName: "eye") : Image(systemName: "eye.slash")
                })
                
            }.padding()
            
            
            HStack{
                Text("相同密码")
                    .font(.system(size: 15))
                    .padding(.leading)
                    .foregroundColor(.gray)
                Spacer()
            }
            
            HStack{
                Text("邮箱:")
                TextField("请输入邮箱", text: $email)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.leading,5)
            }.padding()
            
            
            HStack{
                Text("正确邮箱格式")
                    .font(.system(size: 15))
                    .padding(.leading)
                    .foregroundColor(.gray)
                Spacer()
            }
            
            HStack{
                Text("电话:")
                TextField("请输入电话", text: $phoneNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.leading,5)
            }.padding()
            
            
            HStack{
                Text("11位手机号码")
                    .font(.system(size: 15))
                    .padding(.leading)
                    .foregroundColor(.gray)
                Spacer()
            }
            
            Button{
                name = ""
                password1 = ""
                password2 = ""
                email = ""
                phoneNumber = ""
                erroInfo = ""
            }label: {
                Text("重新输入")
            }
            
            Button {
                addUser()
                InfoCopy=erroInfo
                erroInfo=""
            }
            label: {
                ZStack{
                    RoundedRectangle(cornerRadius: 50)
                        .fill(Color.blue)
                        .frame(width: 300, height: 50)
                    Text("立即注册")
                        .foregroundColor(.white)
                    Spacer()
                }
            }
            .padding()
            .alert(item: $alertType) { alertType in
                switch alertType {
                case .success:
                    return Alert(title: Text("注册成功"), message: Text("请返回登录界面登录"), dismissButton: .default(Text("好")))
                case .failure:
                    return Alert(title: Text("注册失败"), message: Text(InfoCopy), dismissButton: .default(Text("好")))
                }
            }

            
            
            
            .listStyle(.plain)
            .padding()
                        
        }
        .padding()
        .navigationBarBackButtonHidden(true) // 隐藏默认的返回按钮
        .navigationBarItems(leading: Button(action: {
            self.presentationMode.wrappedValue.dismiss() // 执行返回操作
        }) {
            HStack {
                Image(systemName: "arrow.left") // 可以自定义图标
                Text("返回") // 可以自定义文本
            }
        })
        .navigationTitle("注册")
        
    }
    
//    // 添加管理员
//    private func addUser() {
//        print("尝试添加用户")
//        if isRegister() {
//            print("通过验证，准备注册")
//            alertType = .success
//            erroInfo=""
//            let user = Admin(context: viewContext)
//            user.name = name
//            user.password = password1
//            user.admId = UUID()
//            user.email=email
//            do {
//                try viewContext.save()
//                print("用户成功注册.")
//            } catch {
//                let nsError = error as NSError
//                fatalError("发生错误 \(nsError), \(nsError.userInfo)")
//            }
//        }else{
//            alertType = .failure
//        }
//    }
    // 添加用户
    private func addUser() {
        print("尝试添加用户")
        if isRegister() {
            print("通过验证，准备注册")
            alertType = .success
            erroInfo=""
            let user = User(context: viewContext)
            user.name = name
            user.password = password1
            user.userId = UUID()
            user.email=email
            user.phoneNumber=phoneNumber
            do {
                try viewContext.save()
                print("用户成功注册.")
            } catch {
                let nsError = error as NSError
                fatalError("发生错误 \(nsError), \(nsError.userInfo)")
            }
        }else{
            alertType = .failure
        }
    }
    
    private func isRegister() -> Bool {
        
        print("开始验证注册信息")
        
        var flag=true
        if name=="" {
            flag=false
            erroInfo += "用户名不能为空 "
        }
        if !isValidUsername(name){
            flag=false
            erroInfo += "用户名格式错误 "
        }
        if users.contains(where: { $0.name == name }) {
            flag = false
            erroInfo += "用户名已被注册 "
        }
        
        if password1=="" || password2=="" {
            flag=false
            erroInfo += "密码不能为空 "
        }
        
        if !isValidPassword(password1){
            flag=false
            erroInfo += "密码格式错误 "
        }else{
            if password1 != password2 {
                flag=false
                erroInfo += "两次密码不一致 "
            }
        }
        
        if email=="" {
            flag=false
            erroInfo += "邮箱不能为空 "
        }
        
        if !isValidEmail(email){
            flag=false
            erroInfo += "邮箱格式错误 "
        }
        
        if users.contains(where: { $0.email == email }) {
            flag = false
            erroInfo += "邮箱已被注册 "
        }
        
        if phoneNumber=="" {
            flag=false
            erroInfo += "电话不能为空 "
        }
        
        if !isValidPhoneNumber(phoneNumber){
            flag=false
            erroInfo += "电话格式错误 "
        }
        
        if users.contains(where: { $0.phoneNumber == phoneNumber }) {
            flag = false
            erroInfo += "电话号码已被注册 "
        }
        return flag
    }
    
    func isValidUsername(_ username: String) -> Bool {
        // 6到10个字母或数字
        let regex = "^[A-Za-z0-9]{6,10}$"
        return username.range(of: regex, options: .regularExpression) != nil
    }

    func isValidPassword(_ password: String) -> Bool {
        // 最少8个字符，至少1个大写字母、1个小写字母和1个数字
        let regex = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)[A-Za-z\\d]{8,}"
        return password.range(of: regex, options: .regularExpression) != nil
    }

    func isValidEmail(_ email: String) -> Bool {
        // 邮箱格式
        let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        return email.range(of: regex, options: .regularExpression) != nil
    }

    func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
        // 仅允许11位数字
        let regex = "^[0-9]{11}$"
        return phoneNumber.range(of: regex, options: .regularExpression) != nil
    }
    
}

#Preview {
    RegisterView().environmentObject(CoreDataStack(modelName: "SocialPlanModel"))
}
