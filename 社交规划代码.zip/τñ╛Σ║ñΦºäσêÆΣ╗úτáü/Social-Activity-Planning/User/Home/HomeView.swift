//
//  HomeView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/11/30.
//

import SwiftUI
import CoreData

// 主界面
struct HomeView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    var user: User?
    
    let images = ["Image1", "Image2", "Image3"]
    
    @State private var events: [Event] = []
    @State private var UserEvents: [Event] = []
    
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.2).edgesIgnoringSafeArea(.all)
                VStack {
                    // 上下滑动视图
                    ScrollView{
                        //官方公告
                        Text("官方公告")
                            .foregroundColor(.black)
                            .fontWeight(.bold)
                            .padding()
                        TabView {
                            ForEach(images, id: \.self) { imageName in
                                Image(imageName)
                                    .resizable()
                                    .scaledToFill() // 使图片填充整个视图
                                    .tag(imageName) // 标记每个视图，以便于识别
                            }
                        }
                        .padding(.horizontal)
                        .tabViewStyle(PageTabViewStyle())
                        .frame(height: 400)
                            
                        // 官方活动
                        HStack{
                            Text("官方活动")
                                .foregroundColor(.black)
                                .fontWeight(.bold)
                                .padding()
                            Spacer()
                            
                        }.padding()
                        
                            
                        ForEach(events) { event in
                            NavigationLink(destination: AdmEventView(event: event,user: user)) {
                                HStack {
                                    Text(event.eventName ?? "未知活动")
                                        .foregroundColor(.black)
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                }
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(10)
                                .padding(.horizontal)
                            }
                        }
                        
                        // 用户活动
                        HStack{
                            Text("用户活动")
                                .foregroundColor(.black)
                                .fontWeight(.bold)
                                .padding()
                            Spacer()
                            
                        }.padding()
                        
                        ForEach(UserEvents) { event in
                            NavigationLink(destination: AllUserView(event: event,user: user)) {
                                HStack {
                                    Text(event.eventName ?? "")
                                        .foregroundColor(.black)
                                    Spacer()
                                    Text(event.createUser ?? "")
                                        .foregroundColor(.black)
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                }
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(10)
                                .padding(.horizontal)
                            }
                        }
                        
                    }
                    
                }
                
            }
        }
        .onAppear(){
            fetchData()
        }
    }
    
    private func fetchData() {
        let FetchRequest: NSFetchRequest<Event> = Event.fetchRequest()
        FetchRequest.predicate = NSPredicate(format: "createUser == %@","官方")
        FetchRequest.includesSubentities = false
                
        do {
            events = try viewContext.fetch(FetchRequest)
        } catch {
            print("用户创建活动查询失败: \(error)")
            events = []
        }
        
        
        let FetchRequest2: NSFetchRequest<Event> = Event.fetchRequest()
        FetchRequest2.predicate = NSPredicate(format: "createUser != %@ and createUser != %@ and view == %@" ,"官方", user?.name ?? "","公开")
        FetchRequest2.includesSubentities = false
                
        do {
            UserEvents = try viewContext.fetch(FetchRequest2)
        } catch {
            print("用户创建活动查询失败: \(error)")
            UserEvents = []
        }
    }
    
}


#Preview {
    HomeView()
}

