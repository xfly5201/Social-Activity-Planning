//
//  EventDetailView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/4.
//

import SwiftUI
import CoreData

enum AlertTypeEventJoin: Identifiable {
    case success, failure
    var id: Int {
        hashValue
    }
}

// 官方活动的详细内容
struct AdmEventView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    let event: Event
    var user: User?
    
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .short
        return formatter
    }()

    @State private var alertType: AlertTypeEventJoin?
    @State private var partId: UUID = UUID()
    
    var body: some View {
        
        
        VStack {
            
            ScrollView{
                
                HStack{
                    Text("活动名称:")
                    Spacer()
                    Text(event.eventName ?? "未知活动")
                    
                }.padding()
                
                HStack{
                    Text("活动类型:")
                    Spacer()
                    Text(event.type ?? "未知类型")
                }.padding()
                
                HStack{
                    Text("活动开始时间:")
                    Spacer()
                    if let startTime = event.startTime {
                        Text(dateFormatter.string(from: startTime))
                    } else {
                        Text("null")
                    }
                }.padding()
                
                HStack{
                    Text("活动结束时间:")
                    Spacer()
                    if let endTime = event.endTime {
                        Text(dateFormatter.string(from: endTime))
                    } else {
                        Text("null")
                    }
                }.padding()
                
                HStack{
                    Text("活动地点:")
                    Spacer()
                    Text(event.location ?? "未知地点")
                }.padding()
                
                HStack{
                    Text("活动经费:")
                    Spacer()
                    Text(String(format: "%.2f", event.budget))
                }.padding()
                
                HStack{
                    Text("活动详情:")
                    Spacer()
                    Text(event.eventInfo ?? "无详情")
                }.padding()
                
                
                Button(action: {
                    joinEvent()
                }, label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.green)
                            .frame(width: 300, height: 50)
                        Text("加入活动")
                            .foregroundColor(.white)
                        Spacer()
                    }
                })
                .padding()
                .alert(item: $alertType) { alertType in
                    switch alertType {
                    case .success:
                        return Alert(title: Text("加入成功"), message: Text("可以在活动管理看到你的活动"), dismissButton: .default(Text("好")))
                    case .failure:
                        return Alert(title: Text("加入失败"), message: Text("已加入该活动"), dismissButton: .default(Text("好")))
                    }
                }
                
            }
            .font(.headline)
        }
    }
    
    private func joinEvent(){
        print("尝试加入活动")
        if !hasJoin() {
            print("通过验证，准备添加")
            alertType = .success
            
            if hasJoined(){
                changeStatue()
            }
            else {
                let part = Participant(context: viewContext)
                part.eventName = event.eventName
                part.createName = "官方"
                part.inviteName = user?.name
                part.startTime = event.startTime
                part.endTime = event.endTime
                part.eventInfo = event.eventInfo
                part.location = event.location
                part.budget = event.budget
                part.type = event.type
                part.status = "接受"
                part.partId = partId
                part.eventId = event.eventId
            }
            do {
                try viewContext.save()
                print("活动添加成功")
            } catch {
                let nsError = error as NSError
                fatalError("发生错误 \(nsError), \(nsError.userInfo)")
            }
        }else{
            alertType = .failure
        }
    }
    
    // 是否已经参加
    private func hasJoin() -> Bool{
        
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = Participant.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "eventId == %@ and inviteName == %@ and status == %@", event.eventId! as CVarArg , user?.name ?? "用户不存在","接受")
        fetchRequest.includesSubentities = false
        
        do {
            let count = try viewContext.count(for: fetchRequest)
            return count > 0
        } catch {
            print("不存在: \(error)")
            return false
        }
    }
    
    // 是否有参加记录
    private func hasJoined() -> Bool{
        
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = Participant.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "eventId == %@ and inviteName == %@ and status == %@", event.eventId! as CVarArg , user?.name ?? "用户不存在","拒绝")
        fetchRequest.includesSubentities = false
        
        do {
            let count = try viewContext.count(for: fetchRequest)
            return count > 0
        } catch {
            print("不存在: \(error)")
            return false
        }
        
    }
    
    // 接受更改
    private func changeStatue() {
        
        let fetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
                
        fetchRequest.predicate = NSPredicate(format: "eventId == %@ and inviteName == %@ and status == %@", event.eventId! as CVarArg , user?.name ?? "用户不存在","拒绝")

        do {
           
            if let event = try viewContext.fetch(fetchRequest).first {
                event.status = "接受"
                try viewContext.save()
            }else{
                print("未找到符合条件的对象")
            }
                    
        } catch {
            print("更新失败: \(error)")
        }
        
    }
}
