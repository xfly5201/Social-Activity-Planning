//
//  UserInfoView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/8.
//

import SwiftUI
import CoreData

// 编辑个人信息
struct UserInfoView: View {
    
    enum AlertTypeInfo: Identifiable {
        case success, failure
        var id: Int {
            hashValue
        }
    }
    
    let user:User?
    @Environment(\.managedObjectContext) private var viewContext
    @State private var phoneNumber = ""
    @State private var email = ""
    @State private var biography = ""
    
    @State private var alertType: AlertTypeInfo?
    
    @Binding  var refreshManager: Bool
    
    @State private var erroInfo: String = ""
    @State private var InfoCopy: String = ""
    
    
    var body: some View {
        NavigationView{
            VStack {
                Text("编辑资料")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                ScrollView{
                    
                    HStack{
                        Text("用户名:")
                        Spacer()
                        Text(user?.name ?? "")
                        
                    }.padding()
                    
                    HStack{
                        Text("用户编号:")
                        Spacer()
                        Text(user?.userId?.uuidString ?? "")
                        
                    }.padding()
                    
                    
                    HStack{
                        Text("手机:")
                        Spacer()
                        TextField(phoneNumber, text: $phoneNumber)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.leading,5)
                        
                    }.padding()
                    
                    HStack{
                        Text("邮箱:")
                        Spacer()
                        TextField(email, text: $email)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.leading,5)
                        
                    }.padding()
                    
                    HStack{
                        Text("个性签名:")
                        Spacer()
                        TextEditor(text: $biography)
                            .frame(minHeight: 150, maxHeight: 150) // 设置固定高度
                            .background(Color.white)
                            .cornerRadius(20)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                            .padding(.horizontal)
                            .addDoneButtonToKeyboard() // 加入完成按键
                        
                    }.padding()
                    
                    
                    Button(action: {
                        if isOk(){
                            saveInfo()
                            alertType = .success
                            refreshManager.toggle()
                        }
                        else{
                            alertType = .failure
                        }
                        InfoCopy=erroInfo
                        erroInfo=""
                    }, label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 50)
                                .fill(Color.blue)
                                .frame(width: 300, height: 50)
                            Text("保存修改")
                                .foregroundColor(.white)
                            Spacer()
                        }
                    })
                    .alert(item: $alertType) { alertType in
                        switch alertType {
                        case .success:
                            return Alert(title: Text("修改成功"), message: Text("请返回我的界面"), dismissButton: .default(Text("好")))
                        case .failure:
                            return Alert(title: Text("注册失败"), message: Text(InfoCopy), dismissButton: .default(Text("好")))
                        }
                    }
                    
                    
                }
                .font(.headline)
            }
        }
        
        .onAppear(){
            phoneNumber = user?.phoneNumber ?? ""
            email = user?.email ?? ""
            biography = user?.biography ?? ""
        }
    }
    
    private func isOk() -> Bool{
        
        @FetchRequest<User>(
            sortDescriptors: [
                NSSortDescriptor(keyPath: \User.name, ascending: true),
            ],
            predicate : NSPredicate(format: "userId != %@", user?.userId?.uuidString ?? "")
        )var users
        
        var flag = true
        
        if email=="" {
            flag=false
            erroInfo += "邮箱不能为空 "
        }
        
        if !isValidEmail(email){
            flag=false
            erroInfo += "邮箱格式错误 "
        }
        
        if users.contains(where: { $0.email == email }) {
            flag = false
            erroInfo += "邮箱已被注册 "
        }
        
        if phoneNumber=="" {
            flag=false
            erroInfo += "电话不能为空 "
        }
        
        if !isValidPhoneNumber(phoneNumber){
            flag=false
            erroInfo += "电话格式错误 "
        }
        
        if users.contains(where: { $0.phoneNumber == phoneNumber }) {
            flag = false
            erroInfo += "电话号码已被注册 "
        }
        
        return flag;
    }
    
    private func saveInfo(){
        
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
                
        fetchRequest.predicate = NSPredicate(format: "userId == %@", user!.userId! as CVarArg)
                
        do {
           
            if let userCurrent = try viewContext.fetch(fetchRequest).first {
                // 更新对象的属性
                userCurrent.email = email
                userCurrent.phoneNumber = phoneNumber
                userCurrent.biography = biography
                try viewContext.save()
            }else{
                print("未找到符合条件的对象")
            }
                    
        } catch {
            print("更新失败: \(error)")
        }
        
    }

    func isValidEmail(_ email: String) -> Bool {
        // 邮箱格式
        let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        return email.range(of: regex, options: .regularExpression) != nil
    }

    func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
        // 仅允许11位数字
        let regex = "^[0-9]{11}$"
        return phoneNumber.range(of: regex, options: .regularExpression) != nil
    }
    
}

//#Preview {
//   UserInfoView(user: User())
//}


