//
//  addFriendView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/9.
//

import SwiftUI
import CoreData
enum AlertTypeAddFriend: Identifiable {
    case success, failure
    var id: Int {
        hashValue
    }
}

// 添加朋友
struct AddFriendView: View {
    var user: User?
    @Environment(\.managedObjectContext) private var viewContext
    @State private var searchText: String = ""
    
    var body: some View {
        NavigationView {
            FilteredContacts(filter: searchText, user: user!)
                .navigationBarTitle("搜索你要添加的好友", displayMode: .inline)
                .searchable(text: $searchText)
        }
    }
}

struct FilteredContacts: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var alertType: AlertTypeAddFriend?
    @State private var errorInfo: String = ""
    @State private var InfoCopy: String = ""
    
    var user: User?
    let fetchRequest: FetchRequest<User>
    
    init(filter: String, user: User) {
        self.user = user
        let predicate: NSPredicate? = NSPredicate(format: "name CONTAINS[CD] %@ and name != %@ " ,filter,user.name ?? "")
        fetchRequest = FetchRequest<User>(
            sortDescriptors: [
                NSSortDescriptor(keyPath: \User.name, ascending: true)
            ],
            predicate: predicate
        )
    }
    
    // 展示视图
    var body: some View {
        List {
            ForEach(fetchRequest.wrappedValue, id: \.self) { user in
                HStack {
                    Text(user.name ?? "")
                    Spacer()
                    Text(user.email ?? "")
                    Spacer()
                    Button(action: {
                        if hasFriend(friend: user){ // 已经添加好友 ，或者等待好友通过
                            alertType = .failure
                        }
                        else{
                            addFriendSend(friend: user)
                            alertType = .success
                        }
                        InfoCopy=errorInfo
                        errorInfo=""
                    }, label: {
                        Image(systemName: "plus")
                            
                    })
                    .buttonStyle(.bordered)
                    .alert(item: $alertType) { alertType in
                        switch alertType {
                        case .success:
                            return Alert(title: Text("发送成功"), message: Text("好友申请已发送"), dismissButton: .default(Text("好")))
                        case .failure:
                            return Alert(title: Text("发送失败"), message: Text(InfoCopy), dismissButton: .default(Text("好")))
                        }
                    }
                    
                    
                }
            }
        }
        .listStyle(.plain)
    }
    
    private func hasFriend(friend: User) -> Bool{
        
        let fetchRequest1: NSFetchRequest<NSFetchRequestResult> = Friends.fetchRequest()
        fetchRequest1.predicate = NSPredicate(format: "inviteName == %@ and userName == %@ and status == %@", friend.name ?? "", user?.name ?? "", "等待")
        fetchRequest1.includesSubentities = false
        
        let fetchRequest2: NSFetchRequest<NSFetchRequestResult> = Friends.fetchRequest()
        fetchRequest2.predicate = NSPredicate(format: "inviteName == %@ and userName == %@ and status == %@", friend.name ?? "", user?.name ?? "", "接受")
        fetchRequest2.includesSubentities = false
        
        do {
            let count1 = try viewContext.count(for: fetchRequest1)
            let count2 = try viewContext.count(for: fetchRequest2)
            if count1>0 {
                errorInfo="不能重复发送申请，请耐心等待"
                return true
            }
            if count2>0 {
                errorInfo="你们已经是朋友了"
                return true
            }
            else {
                return false
            }
        } catch {
            print("不存在: \(error)")
            return false
        }
        
    }
    
    private func addFriendSend(friend: User){
        
        if hasRefuse(friend: friend) {
            let fetchRequest1: NSFetchRequest<Friends> = Friends.fetchRequest()
            fetchRequest1.predicate = NSPredicate(format: "inviteName == %@ and userName == %@ and status == %@", friend.name ?? "", user?.name ?? "", "拒绝")

            let fetchRequest2: NSFetchRequest<Friends> = Friends.fetchRequest()
            fetchRequest2.predicate = NSPredicate(format: "userName == %@ and inviteName == %@ and status == %@", friend.name ?? "", user?.name ?? "", "拒绝")

            do {
                if let friendship1 = try viewContext.fetch(fetchRequest1).first {
                    friendship1.status = "等待"
                    friendship1.invitor = user?.name ?? ""
                }

                if let friendship2 = try viewContext.fetch(fetchRequest2).first {
                    friendship2.status = "等待"
                    friendship2.invitor = nil
                }
                try viewContext.save()

            } catch {
                print("更新失败: \(error)")
            }
        }
        else{
            let friends1 = Friends(context: viewContext)
            friends1.userName = user?.name ?? ""
            friends1.inviteName = friend.name ?? ""
            friends1.status = "等待"
            friends1.invitor = user?.name ?? ""
            let friends2 = Friends(context: viewContext)
            friends2.userName = friend.name ?? ""
            friends2.inviteName = user?.name ?? ""
            friends2.status = "等待"
            do {
                try viewContext.save()
                print("好友申请已发送")
            } catch {
                let nsError = error as NSError
                fatalError("发生错误 \(nsError), \(nsError.userInfo)")
            }
        }
        
        
    }
    
    private func hasRefuse(friend: User) -> Bool{
        
        let fetchRequest1: NSFetchRequest<NSFetchRequestResult> = Friends.fetchRequest()
        fetchRequest1.predicate = NSPredicate(format: "inviteName == %@ and userName == %@ and status == %@", friend.name ?? "", user?.name ?? "", "拒绝")
        fetchRequest1.includesSubentities = false
        
        let fetchRequest2: NSFetchRequest<NSFetchRequestResult> = Friends.fetchRequest()
        fetchRequest2.predicate = NSPredicate(format: "inviteName == %@ and userName == %@ and status == %@", user?.name ?? "", friend.name ?? "", "拒绝")
        fetchRequest2.includesSubentities = false
        
        do {
            let count1 = try viewContext.count(for: fetchRequest1)
            let count2 = try viewContext.count(for: fetchRequest1)
            if count1>0{
                return true
            }
            else if count2>0{
                return true
            }
            else {
                return false
            }
        } catch {
            print("不存在: \(error)")
            return false
        }
        
    }
    
}

#Preview {
    AddFriendView()
}
