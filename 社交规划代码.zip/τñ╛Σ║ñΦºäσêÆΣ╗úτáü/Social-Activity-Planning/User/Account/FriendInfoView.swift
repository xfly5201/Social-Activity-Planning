//
//  FriendInfoView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/9.
//

import SwiftUI
import CoreData
import Combine


// 处理朋友信息
struct FriendInfoView: View {
    @Environment(\.managedObjectContext) private var viewContext
    var user: User?
    
    @State private var waitToChose = false
    @State private var waitToPass = false
    
    @State private var isRefreshing = false // 刷新状态
    
    @State private var waitChose: [Friends] = []
    @State private var waitPass: [Friends] = []
    
    @State private var alertFirst = false
    @State private var alertSecond = false
    
    @Binding  var refreshManager: Bool
    
    var body: some View {
        NavigationView{
            List {
                Section(header: Text("我收到的申请").foregroundColor(.black).font(.title).fontWeight(.bold).padding()) {
                    
                    DisclosureGroup("待处理申请", isExpanded: $waitToChose) {
                        ForEach(waitChose) { friend in
                            HStack {
                                Text(friend.userName ?? "")
                                    .foregroundColor(.black)
                                    .font(.headline)
                                Spacer()
                                
                                Button {
                                    AgreeFriend(friend: friend)
                                    alertFirst.toggle()
                                    refreshManager.toggle()
                                } label: {
                                    Image(systemName: "checkmark")
                                }
                                .buttonStyle(.bordered)
                                
                                .alert(isPresented: $alertFirst){
                                    Alert(title: Text("添加成功"), message: Text("可以在好友列表看到你的好友"), dismissButton: .default(Text("好")))
                                }
                                
                                
                                Button {
                                    DisAgreeFriend(friend: friend)
                                    alertSecond.toggle()
                                } label: {
                                    Image(systemName: "xmark")
                                }
                                .buttonStyle(.bordered)
                                
                                .alert(isPresented: $alertSecond){
                                    Alert(title: Text("拒绝成功"), message: Text("已经拒绝该用户的邀请"), dismissButton: .default(Text("好")))
                                }
                    
                                
                            }
                        }
                        
                    }.font(.headline)

                    
                }
                
                Section(header: Text("我发送的申请").foregroundColor(.black).font(.title).fontWeight(.bold).padding()) {
                    
                    DisclosureGroup("等待好友通过", isExpanded: $waitToPass) {
                        ForEach(waitPass) { friend in
                            HStack {
                                Text(friend.inviteName ?? "")
                                    .foregroundColor(.black)
                                    .font(.headline)
                                Spacer()
                                Text(friend.status ?? "")
                                    .foregroundColor(.black)
                                    .font(.headline)
                            }
                        }
                    }.font(.headline)
                    
                }
            }
            .foregroundColor(.black)
            .navigationBarTitle("好友申请", displayMode: .inline)
        }
        .onAppear {
            fetchData()
        }
        .onReceive(Just(isRefreshing)) { _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { // 延迟 1秒
                    fetchData()
                    isRefreshing = false
                }
        }
    }
        
    
    // 获取数据
    private func fetchData() {
        
        let waitChoseFetchRequest: NSFetchRequest<Friends> = Friends.fetchRequest()
        waitChoseFetchRequest.predicate = NSPredicate(format: "inviteName == %@ and status == %@ and invitor != %@ ", user?.name ?? "" , "等待", user?.name ?? "")
        waitChoseFetchRequest.includesSubentities = false
        
        // 更新 waitChose
        do {
            waitChose = try viewContext.fetch(waitChoseFetchRequest)
        } catch {
            print("用户创建活动查询失败: \(error)")
            waitChose = []
        }

        let waitPassFetchRequest: NSFetchRequest<Friends> = Friends.fetchRequest()
        waitPassFetchRequest.predicate = NSPredicate(format: "invitor == %@ and status != %@ ", user?.name ?? "", "接受")
        waitPassFetchRequest.includesSubentities = false
        
        do {
            waitPass = try viewContext.fetch(waitPassFetchRequest)
        } catch {
            print("用户接受活动查询失败: \(error)")
            waitPass = []
        }
        
    }
    
    private func AgreeFriend(friend: Friends){
        let fetchRequest1: NSFetchRequest<Friends> = Friends.fetchRequest()
        fetchRequest1.predicate = NSPredicate(format: "inviteName == %@ and userName == %@ and status == %@", friend.userName ?? "", user?.name ?? "", "等待")

        let fetchRequest2: NSFetchRequest<Friends> = Friends.fetchRequest()
        fetchRequest2.predicate = NSPredicate(format: "userName == %@ and inviteName == %@ and status == %@", friend.userName ?? "", user?.name ?? "", "等待")

        do {
            if let friendship1 = try viewContext.fetch(fetchRequest1).first {
                friendship1.status = "接受"
                friendship1.invitor = nil
            }
            if let friendship2 = try viewContext.fetch(fetchRequest2).first {
                friendship2.status = "接受"
                friendship2.invitor = nil
            }
            try viewContext.save()

        } catch {
            print("更新失败: \(error)")
        }
    }
    
    
    private func DisAgreeFriend(friend: Friends){
        let fetchRequest1: NSFetchRequest<Friends> = Friends.fetchRequest()
        fetchRequest1.predicate = NSPredicate(format: "inviteName == %@ and userName == %@ and status == %@", friend.userName ?? "", user?.name ?? "", "等待")

        let fetchRequest2: NSFetchRequest<Friends> = Friends.fetchRequest()
        fetchRequest2.predicate = NSPredicate(format: "userName == %@ and inviteName == %@ and status == %@", friend.userName ?? "", user?.name ?? "", "等待")

        do {
            if let friendship1 = try viewContext.fetch(fetchRequest1).first {
                friendship1.status = "拒绝"
                friendship1.invitor = nil
            }
            if let friendship2 = try viewContext.fetch(fetchRequest2).first {
                friendship2.status = "拒绝"
                friendship2.invitor = nil
            }
            try viewContext.save()

        } catch {
            print("更新失败: \(error)")
        }
    }
}

//#Preview {
//    FriendInfoView()
//}
