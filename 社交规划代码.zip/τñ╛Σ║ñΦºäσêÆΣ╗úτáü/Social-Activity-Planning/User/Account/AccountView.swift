//
//  AccountView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/3.
//

import SwiftUI
import UIKit
import CoreData
import Combine

// 我的
struct AccountView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    var user: User?
    
    @State private var isLoggedIn: Bool = true
    @State private var isLoggedOut: Bool = false
    
    @State private var selectedImage: UIImage?
    @State private var selectedBackgroundImage: UIImage?
    @State private var isImagePickerPresented: Bool = false
    @State private var isBackgroundImagePickerPresented: Bool = false
    
    @State private var select: Int = 0
    @State private var biographyInfo: String = ""
    @State private var alertOver: Bool = false
    
    @State private var isRefreshing = false // 刷新状态
    
    @State private var bianji:Bool = false
    @State private var setting:Bool = false
    @State private var addFriends:Bool = false
    @State private var infoFriend:Bool = false
    
    @State private var myFriends: [Friends] = []
    
    @State private var isDelete:Bool = false
    
    var body: some View {
        ZStack {
            Color.white.opacity(0.2).edgesIgnoringSafeArea(.all)
            VStack {
                
                ScrollView {
                    
                    ZStack{
                        if let selectedBackgroundImage = selectedBackgroundImage {
                            Image(uiImage: selectedBackgroundImage)
                                .resizable()
                        } else {
                            Image("Image4") // 默认背景
                                .resizable()
                        }
                        
                        
                        Color.black.opacity(0.4)
                        
                        //头像图片的选择
                        VStack{
                            
                            HStack{
                                if let selectedImage = selectedImage {
                                    Image(uiImage: selectedImage)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 100, height: 100)
                                        .clipShape(Circle())
                                        .overlay(Circle().stroke(Color.white, lineWidth: 4))
                                        .shadow(radius: 10)
                                    
                                        .onTapGesture {
                                            isImagePickerPresented = true
                                        }
                                } else {
                                    Image("Image1") // 默认头像
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 100, height: 100)
                                        .clipShape(Circle())
                                        .overlay(Circle().stroke(Color.white, lineWidth: 4))
                                        .shadow(radius: 10)
                                    
                                        .onTapGesture {
                                            isImagePickerPresented = true
                                        }
                                }
                                
                                VStack(alignment: .leading, spacing: 8){
                                    Text(user?.name ?? "")
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .fontWeight(.bold)
                                    Text("编号："+(user?.userId?.uuidString ?? ""))
                                        .font(.footnote)
                                        .foregroundColor(.white.opacity(0.6))
                                    
                                }
                                
                                Spacer()
                            }
                            .padding(.top,100)
                            .padding(.horizontal,30)
                            
                            Spacer()
                            
                            HStack{
                                Button(action: {
                                    isBackgroundImagePickerPresented = true
                                }, label: {
                                    Text("背景更换")
                                        .foregroundColor(.white)
                                        .padding(.vertical,2)
                                        .padding(.horizontal,20)
                                        .background(
                                            .ultraThinMaterial,in:
                                                RoundedRectangle(cornerRadius: 10)
                                        )
                                })
                                
                                Spacer()
                                
                                
                                Button(action: {
                                    bianji.toggle()
                                }, label: {
                                    Text("编辑资料")
                                        .foregroundColor(.white)
                                        .padding(.vertical,2)
                                        .padding(.horizontal,20)
                                        .background(
                                            .ultraThinMaterial,in:
                                                RoundedRectangle(cornerRadius: 10)
                                        )
                                })
                                .sheet(isPresented: $bianji) {
                                    UserInfoView(user: user, refreshManager: $isRefreshing)
                                }
                                
                                Button(action: {
                                    setting.toggle()
                                }, label: {
                                    Image(systemName: "gearshape")
                                        .foregroundColor(.white)
                                        .padding(.vertical,2)
                                        .padding(.horizontal,20)
                                        .background(
                                            .ultraThinMaterial,in:
                                                RoundedRectangle(cornerRadius: 10)
                                        )
                                })
                                .sheet(isPresented: $setting) {
                                    SettingView(user: user, setting: $setting, isLoggedIn: $isLoggedIn, isLoggedOut: $isLoggedOut)
                                }
                                
                                
                            }
                            .padding()
                            .padding(.bottom,50)
                            
                        }
                        
                    }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height/2 , alignment: .center)
                    
                    VStack{
                        
                        HStack(spacing:40){
                            Button(action: {
                                select=0
                            }, label: {
                                Text("个性签名")
                                    .foregroundColor(select == 0 ? .black:.gray)
                            })
                            
                            Button(action: {
                                select=1
                            }, label: {
                                Text("好友列表")
                                    .foregroundColor(select == 1 ? .black:.gray)
                            })
                            
                        }.padding(10)
                            .font(.system(size: 15))
                        
                        TabView(selection: $select){
                            
                            VStack{
                                
                                Text(user?.biography ?? "请输入个性签名")
                                    .frame(width: UIScreen.main.bounds.width-30,height: 150)
                                    .background(Color.white)
                                    .cornerRadius(20)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color.gray, lineWidth: 1)
                                    )
                                    .padding(.horizontal)
                                
                                Spacer()
                                
                            }.tag(0)
                            
                            
                            
                            VStack{
                                
                                HStack{
                                    Button {
                                        addFriends.toggle()
                                    } label: {
                                        Image(systemName: "person.2")
                                    }
                                    .sheet(isPresented: $addFriends) {
                                        AddFriendView(user: user)
                                    }
                                    
                                    Spacer()
                                    
                                    Button {
                                        infoFriend.toggle()
                                    } label: {
                                        Image(systemName: "message.badge")
                                    }
                                    .sheet(isPresented: $infoFriend) {
                                        FriendInfoView(user: user,refreshManager: $isRefreshing)
                                    }
                                }
                                .padding(.horizontal,50)
                                Spacer()
                                
                                List {
                                    ForEach(myFriends){ friend in
                                        HStack {
                                            Text(friend.inviteName ?? "")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                            Spacer()
                                            Button {
                                                DeleteFriend(friend: friend)
                                                isDelete.toggle()
                                            } label: {
                                                Image(systemName: "xmark")
                                            }
                                            .buttonStyle(.bordered)
                                            .alert(isPresented: $isDelete){
                                                Alert(title: Text("删除成功"), message: Text("已经将该好友删除"), dismissButton: .default(Text("好")))
                                            }
                                            
                                        }
                                    }.font(.headline)
                                    
                                }
                                
                            }.tag(1)
                            
                        }
                        .padding(.top,40)
                        .tabViewStyle(.page(indexDisplayMode: .never))
                        .frame(minHeight: 350,maxHeight: .infinity)
                        
                        
                    }
                    .foregroundColor(.black)
                    .background(.white,in: RoundedRectangle(cornerRadius: 30))
                    .offset(y:-50)
                    
                    
                    if isLoggedOut {
                        NavigationLink(destination: LoginView(), isActive: $isLoggedOut) {
                            EmptyView()
                        }
                    }
                    
                }
            }
            .ignoresSafeArea()
        }
        // 图片选择处理
        .sheet(isPresented: $isImagePickerPresented) {
            ImagePicker(image: $selectedImage, didSelectImage: { newImage in
                if let newImage = newImage {
                    selectedImage = newImage
                }
            })
        }
        .sheet(isPresented: $isBackgroundImagePickerPresented) {
            BackgroundImagePicker(image: $selectedBackgroundImage, didSelectImage: { newImage in
                if let newImage = newImage {
                    selectedBackgroundImage = newImage
                }
            })
        }
        
        
        .onAppear {
            
            fetchData()
            
            biographyInfo = user?.biography ?? ""
            
            if let userId = UserDefaults.standard.string(forKey: "loggedInUserId") {
                if let imageData = UserDefaults.standard.data(forKey: "user\(userId)Image"),
                   let uiImage = UIImage(data: imageData) {
                    selectedImage = uiImage
                }
            }
            
            if let userId = UserDefaults.standard.string(forKey: "loggedInUserId") {
                if let imageData = UserDefaults.standard.data(forKey: "user\(userId)BackgroundImage"),
                   let uiImage = UIImage(data: imageData) {
                    selectedBackgroundImage = uiImage
                }
            }
            
        }
        
        .onReceive(Just(isRefreshing)) { _ in
            biographyInfo = user?.biography ?? ""
            fetchData()
        }
    }
    
    private func fetchData() {
        
        let FetchRequest: NSFetchRequest<Friends> = Friends.fetchRequest()
        FetchRequest.predicate = NSPredicate(format: "userName == %@ and status == %@", user?.name ?? "" , "接受")
        FetchRequest.includesSubentities = false
        
        do {
            myFriends = try viewContext.fetch(FetchRequest)
        } catch {
            print("用户创建活动查询失败: \(error)")
            myFriends = []
        }
        
    }
    
    private func DeleteFriend(friend: Friends){
        
        let fetchRequest1: NSFetchRequest<Friends> = Friends.fetchRequest()
        fetchRequest1.predicate = NSPredicate(format: "inviteName == %@ and userName == %@ and status == %@", friend.inviteName ?? "", user?.name ?? "", "接受")
        
        let fetchRequest2: NSFetchRequest<Friends> = Friends.fetchRequest()
        fetchRequest2.predicate = NSPredicate(format: "userName == %@ and inviteName == %@ and status == %@", friend.inviteName ?? "", user?.name ?? "", "接受")
    
        do {
            if let friendship1 = try viewContext.fetch(fetchRequest1).first {
                friendship1.status = "拒绝"
                friendship1.invitor = nil
            }
            if let friendship2 = try viewContext.fetch(fetchRequest2).first {
                friendship2.status = "拒绝"
                friendship2.invitor = nil
            }
            try viewContext.save()
            
        } catch {
            print("更新失败: \(error)")
        }
    }
}


#Preview {
    AccountView()
}


