//
//  SettingView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/12.
//

import SwiftUI

// 设置
struct SettingView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    var user: User?
    
    @Binding var setting: Bool
    @Binding var isLoggedIn: Bool
    @Binding var isLoggedOut: Bool
    @State private var showAlert: Bool = false
    
    
    var body: some View {
        ZStack {
            Color.white.opacity(0.2).edgesIgnoringSafeArea(.all)
            VStack {
                Button("退出登录") {
                    UserDefaults.standard.removeObject(forKey: "loggedInUserId")
                    isLoggedIn = false
                    showAlert = true
                }
                .alert(isPresented: $showAlert) {
                    Alert(
                        title: Text("成功退出"),
                        message: Text("请重新登录"),
                        dismissButton: .default(Text("好")) {
                            isLoggedOut = true
                            setting = false
                        }
                    )
                }
            }
            if isLoggedOut {
                NavigationLink(destination: LoginView(), isActive: $isLoggedOut) {
                    EmptyView()
                }
            }
            
        }
        .ignoresSafeArea()
    }
}
