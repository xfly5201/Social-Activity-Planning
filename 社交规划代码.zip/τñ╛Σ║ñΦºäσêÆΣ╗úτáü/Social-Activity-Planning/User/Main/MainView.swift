//
//  MainView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/2.
//

import SwiftUI

struct MainView: View {
    var user: User?
    @State var selectedTab: SelectionTabbar = .home
    var body: some View {
        
        NavigationView {
            VStack {
                // 根据选择的选项卡显示对应的视图
                switch selectedTab {
                case .home:
                    HomeView(user: user)
                case .set:
                    SetView(user: user)
                case .manage:
                    ManagerView(user: user)
                case .account:
                    AccountView(user: user)
                }

                TabbarView(select: $selectedTab)
                    .padding(.bottom,40)
            }
            .navigationBarHidden(true)
            .edgesIgnoringSafeArea(.bottom) // 忽略安全区域
        }
        .navigationBarBackButtonHidden(true)
    }
}

//#Preview {
//    MainView()
//}
