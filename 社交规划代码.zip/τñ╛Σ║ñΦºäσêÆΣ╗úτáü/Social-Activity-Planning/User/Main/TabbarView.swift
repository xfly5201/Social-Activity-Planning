//
//  TabbarView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/2.
//

import SwiftUI


enum SelectionTabbar{
    case home
    case set
    case manage
    case account
}

// 导航栏视图
struct TabbarView: View {
    @Binding var select: SelectionTabbar
    var body: some View {
        HStack{
            Spacer()
            Button{
                select = .home
            }label: {
                Text("首页")
            }
            .foregroundColor(select == .home ? .black : .gray)
            
            Spacer()

            Button{
                select = .set
            }label: {
                Text("发起活动")
            }
            .foregroundColor(select == .set ? .black : .gray)
            Spacer()


            Button{
                select = .manage
            }label: {
                Text("活动管理")
            }
            .foregroundColor(select == .manage ? .black : .gray)
            Spacer()

            Button{
                select = .account
            }label: {
                Text("我的")
            }
            .foregroundColor(select == .account ? .black : .gray)
            Spacer()

        }
        .padding(.top)
        .background(.white)
    }
    
}

//#Preview {
//    TabbarView(select: MainView().$selectedTab)
//}
