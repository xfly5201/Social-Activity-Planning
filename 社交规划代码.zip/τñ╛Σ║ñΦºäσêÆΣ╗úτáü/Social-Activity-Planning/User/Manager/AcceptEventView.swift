//
//  AcceptEventView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/5.
//

import SwiftUI

// 我接受的活动
struct AcceptEventView: View {
    
    let event: Participant
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .short
        return formatter
    }()
    
    @State private var showFriend: Bool = false
    
    var body: some View {
        VStack {
            
            ScrollView{
                
                HStack{
                    Text("活动创建人:")
                    Spacer()
                    Text(event.createName ?? "未知人")
                    
                }.padding()
                
                HStack{
                    Text("活动名称:")
                    Spacer()
                    Text(event.eventName ?? "未知活动")
                    
                }.padding()
                
                HStack{
                    Text("活动类型:")
                    Spacer()
                    Text(event.type ?? "未知类型")
                }.padding()
                
                HStack{
                    Text("活动开始时间:")
                    Spacer()
                    if let startTime = event.startTime {
                        Text(dateFormatter.string(from: startTime))
                    } else {
                        Text("null")
                    }
                }.padding()
                
                HStack{
                    Text("活动结束时间:")
                    Spacer()
                    if let endTime = event.endTime {
                        Text(dateFormatter.string(from: endTime))
                    } else {
                        Text("null")
                    }
                }.padding()
                
                HStack{
                    Text("活动地点:")
                    Spacer()
                    Text(event.location ?? "未知地点")
                }.padding()
                
                HStack{
                    Text("活动经费:")
                    Spacer()
                    Text(String(format: "%.2f", event.budget))
                }.padding()
                
                HStack{
                    Text("活动详情:")
                    Spacer()
                    Text(event.eventInfo ?? "无详情")
                }.padding()
                
                Button(action: {
                    showFriend.toggle()
                }, label: {
                    Image(systemName: "person.circle")
                })
                .padding()
                
                .sheet(isPresented: $showFriend) {
                    AccpetEventPersonView(event: event)
                }
                
                
            }
            .font(.headline)
        }
    }
}

//#Preview {
//    AcceptEventView()
//}
