//
//  PersonJoinView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/10.
//

import SwiftUI
import CoreData

// 朋友加入该活动的情况
struct PersonJoinView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    let event: Event
    @State private var whoJoin: [Participant] = []
    
    var body: some View {
        List {
            ForEach(whoJoin){ friend in
                HStack {
                    Text(friend.inviteName ?? "")
                        .foregroundColor(.black)
                        .font(.headline)
                    Spacer()
                    Text(friend.status ?? "")
                        .foregroundColor(.black)
                        .font(.headline)
                }
            }.font(.headline)
            
                
        }
        .onAppear {
            fetchData()
        }
    }
    
    private func fetchData() {
        let FetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
        FetchRequest.predicate = NSPredicate(format: "eventId == %@", event.eventId! as CVarArg )
        FetchRequest.includesSubentities = false
                
        do {
            whoJoin = try viewContext.fetch(FetchRequest)
        } catch {
            print("用户创建活动查询失败: \(error)")
            whoJoin = []
        }
    }
}

//#Preview {
//    PersonJoinView()
//}
