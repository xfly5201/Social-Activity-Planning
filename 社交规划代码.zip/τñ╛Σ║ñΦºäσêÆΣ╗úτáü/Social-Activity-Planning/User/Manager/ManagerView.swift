//
//  ManagerView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/3.
//

import SwiftUI
import CoreData
import Combine

struct ManagerView: View {
    
    var user: User?
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var isRefreshing = false // 刷新状态
    
    @State private var Mystart = false
    @State private var Myaccept = false
    @State private var InviteMe = false
    @State private var InvitedMe = false
    
    // 建立的活动
    @State private var myEvents: [Event] = []
    
    // 接受的活动
    @State private var acceptEvents: [Participant] = []
    
    // 待处理的邀请
    @State private var pendingEvents: [Participant] = []
    
    // 已处理的邀请
    @State private var processedEvents: [Participant] = []
    
    
    var body: some View {
            ZStack {
                Color.gray.opacity(0.2).edgesIgnoringSafeArea(.all)
                NavigationView {
                    List {
                        Section(header: Text("我参加的活动").foregroundColor(.black).font(.title).fontWeight(.bold).padding()) {
                            
                            DisclosureGroup("我发起的活动", isExpanded: $Mystart) {
                                ForEach(myEvents) { event in
                                    NavigationLink(destination: MyEventView(event: event)) {
                                        HStack {
                                            Text(event.eventName ?? "")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                            Spacer()
                                            Text(event.view ?? "")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                        }
                                    }
                                }
                                .onDelete(perform: deleteMyEvents)
                            }.font(.headline)
                            
                            
                            DisclosureGroup("我接受的活动", isExpanded: $Myaccept) {
                                ForEach(acceptEvents) { event in
                                    NavigationLink(destination: AcceptEventView(event: event)) {
                                        HStack {
                                            Text(event.eventName ?? "未知活动")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                            Spacer()
                                            Text(event.createName ?? "未知用户")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                        }
                                    }
                                }.onDelete(perform: deleteAcceptEvents)
                            }.font(.headline)
                                
                            
                            
                        }
                        
                        Section(header: Text("我收到的邀请").foregroundColor(.black).font(.title).fontWeight(.bold).padding()) {
                            
                            DisclosureGroup("待处理的邀请", isExpanded: $InviteMe) {
                                ForEach(pendingEvents) { event in
                                    NavigationLink(destination: PendingEventView(event: event,refreshManager: $isRefreshing)) {
                                        HStack {
                                            Text(event.eventName ?? "未知活动")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                            Spacer()
                                            Text(event.createName ?? "未知用户")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                        }
                                    }
                                }
                            }.font(.headline)
                            

                            DisclosureGroup("已处理的邀请", isExpanded: $InvitedMe) {
                                ForEach(processedEvents) { event in
                                    NavigationLink(destination: ProcessedEventView(event: event)) {
                                        HStack {
                                            Text(event.eventName ?? "未知活动")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                            Spacer()
                                            Text(event.createName ?? "未知用户")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                            Spacer()
                                            Text(event.status ?? "未知状态")
                                                .foregroundColor(.black)
                                                .font(.headline)
                                        }
                                    }
                                }
                                
                            }.font(.headline)
                            
                        }
                    }
                    .foregroundColor(.black)
                    .navigationBarTitle("活动管理", displayMode: .inline)
                }
                .onAppear {
                    fetchData()
                }
                .onReceive(Just(isRefreshing)) { _ in
                    fetchData()
                }
            }
        }

    private func deleteMyEvents(at offsets: IndexSet) {
        for index in offsets {
            let event = myEvents[index]
            deletePart(event: event)
            viewContext.delete(event)
        }

        do {
            try viewContext.save()
            isRefreshing.toggle()
        } catch {
            print("保存失败: \(error)")
        }
    }
    
    private func deleteAcceptEvents(at offsets: IndexSet) {
        for index in offsets {
            let event = acceptEvents[index]
            viewContext.delete(event)
        }
        do {
            try viewContext.save()
            isRefreshing.toggle()
        } catch {
            print("保存失败: \(error)")
        }
    }
    
    
    private func deletePart(event: Event){
        
        let fetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
                
        fetchRequest.predicate = NSPredicate(format: "eventId == %@", event.eventId! as CVarArg)
                
        do {
            let events = try viewContext.fetch(fetchRequest)
            for event in events {
                viewContext.delete(event)
            }
            try viewContext.save()
        } catch {
            print("更新失败: \(error)")
        }
        
        
    }
    
    
    // 获取数据
    private func fetchData() {
        // 更新 myEvents
        let myEventsFetchRequest: NSFetchRequest<Event> = Event.fetchRequest()
        myEventsFetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Event.view, ascending: true)]
        myEventsFetchRequest.predicate = NSPredicate(format: "createUser == %@", user?.name ?? "")
        myEventsFetchRequest.includesSubentities = false
        
        do {
            myEvents = try viewContext.fetch(myEventsFetchRequest)
        } catch {
            print("用户创建活动查询失败: \(error)")
            myEvents = []
        }
        
        // 更新 acceptEvents
        let acceptEventsFetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
        acceptEventsFetchRequest.predicate = NSPredicate(format: "inviteName == %@ and status == %@", user?.name ?? "", "接受")
        acceptEventsFetchRequest.includesSubentities = false
        
        do {
            acceptEvents = try viewContext.fetch(acceptEventsFetchRequest)
        } catch {
            print("用户接受活动查询失败: \(error)")
            acceptEvents = []
        }
        
        // 更新 pendingEvents
        let pendingEventsFetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
        pendingEventsFetchRequest.predicate = NSPredicate(format: "inviteName == %@ and status == %@", user?.name ?? "", "等待")
        pendingEventsFetchRequest.includesSubentities = false
        
        do {
            pendingEvents = try viewContext.fetch(pendingEventsFetchRequest)
        } catch {
            print("待处理邀请查询失败: \(error)")
            pendingEvents = []
        }
        
        // 更新 processedEvents
        let processedEventsFetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
        processedEventsFetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \Participant.status, ascending: true)]
        processedEventsFetchRequest.predicate = NSPredicate(format: "inviteName == %@ and status != %@", user?.name ?? "", "等待")
        processedEventsFetchRequest.includesSubentities = false
        
        do {
            processedEvents = try viewContext.fetch(processedEventsFetchRequest)
        } catch {
            print("已处理邀请查询失败: \(error)")
            processedEvents = []
        }
    }
    
    
}

#Preview {
    ManagerView()
}
