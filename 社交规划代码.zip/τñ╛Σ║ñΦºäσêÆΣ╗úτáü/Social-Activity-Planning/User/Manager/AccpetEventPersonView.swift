//
//  AccpetEventPersonView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/10.
//

import SwiftUI
import CoreData

// 同意参加该活动的朋友
struct AccpetEventPersonView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    let event: Participant
    @State private var whoJoin: [Participant] = []
    
    var body: some View {
        List {
            Text("参加人员")
                .font(.title)
                .fontWeight(.bold)
            ForEach(whoJoin){ friend in
                HStack {
                    Text(friend.inviteName ?? "")
                        .foregroundColor(.black)
                        .font(.headline)
                }
            }.font(.headline)
        }
        .onAppear {
            fetchData()
        }
    }
    
    private func fetchData() {
        let FetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
        FetchRequest.predicate = NSPredicate(format: "eventId == %@ and status == %@", event.eventId! as CVarArg , "接受")
        FetchRequest.includesSubentities = false
                
        do {
            whoJoin = try viewContext.fetch(FetchRequest)
        } catch {
            print("用户创建活动查询失败: \(error)")
            whoJoin = []
        }
    }
}

//#Preview {
//    AccpetEventPersonView()
//}
