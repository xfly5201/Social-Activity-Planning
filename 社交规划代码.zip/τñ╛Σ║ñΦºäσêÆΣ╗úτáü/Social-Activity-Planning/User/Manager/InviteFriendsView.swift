//
//  InviteFriendsView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/10.
//

import SwiftUI
import CoreData
import Combine


enum AlertTypeSendInvite: Identifiable {
    case success, failure
    var id: Int {
        hashValue
    }
}

// 活动邀请朋友
struct InviteFriendsView: View {
    let event: Event
    
    @State private var myFriends: [Friends] = []
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var setInvite: Bool = false
    @State private var alertType: AlertTypeSendInvite?
    @State private var errorInfo: String = ""
    @State private var InfoCopy: String = ""
    
    var body: some View {
        NavigationView{
            
            List {
                ForEach(myFriends){ friend in
                    HStack {
                        Text(friend.inviteName ?? "")
                            .foregroundColor(.black)
                            .font(.headline)
                        Spacer()
                        Button {
                            if hasInvite(friend: friend.inviteName ?? ""){
                                alertType = .failure
                            }
                            else {
                                InviteWay(friend: friend.inviteName ?? "")
                                alertType = .success
                            }
                            InfoCopy=errorInfo
                            errorInfo=""
                        } label: {
                            Image(systemName: "plus")
                        }
                        .buttonStyle(.bordered)
                        .alert(item: $alertType) { alertType in
                            switch alertType {
                            case .success:
                                return Alert(title: Text("发送成功"), message: Text("等待好友同意你的邀请"), dismissButton: .default(Text("好")))
                            case .failure:
                                return Alert(title: Text("发送失败"), message: Text(InfoCopy), dismissButton: .default(Text("好")))
                            }
                        }
                        
                    }
                }.font(.headline)
            }
                .foregroundColor(.black)
                .navigationBarTitle("好友列表", displayMode: .inline)
            }
        
        .onAppear {
            fetchData()
        }
    }
            
    private func fetchData() {
                
        let FetchRequest: NSFetchRequest<Friends> = Friends.fetchRequest()
        FetchRequest.predicate = NSPredicate(format: "userName == %@ and status == %@", event.createUser ?? "" , "接受")
        FetchRequest.includesSubentities = false
                
        do {
            myFriends = try viewContext.fetch(FetchRequest)
        } catch {
            print("用户创建活动查询失败: \(error)")
            myFriends = []
        }

    }
    
    private func hasInvite(friend: String) -> Bool{
        
        let fetchRequest1: NSFetchRequest<NSFetchRequestResult> = Participant.fetchRequest()
        fetchRequest1.predicate = NSPredicate(format: "inviteName == %@ and eventId == %@ and status == %@", friend, event.eventId! as CVarArg , "等待")
        fetchRequest1.includesSubentities = false
        
        let fetchRequest2: NSFetchRequest<NSFetchRequestResult> = Participant.fetchRequest()
        fetchRequest2.predicate = NSPredicate(format: "inviteName == %@ and eventId == %@ and status == %@", friend, event.eventId! as CVarArg , "接受")
        fetchRequest2.includesSubentities = false
        
        do {
            let count1 = try viewContext.count(for: fetchRequest1)
            let count2 = try viewContext.count(for: fetchRequest2)
            if  count1>0 {
                errorInfo = "不能重复发送邀请，请等待对方同意"
                return true
            }
            if count2>0 {
                errorInfo = "对方已参加该活动"
                return true
            }
            return false
        } catch {
            print("不存在: \(error)")
            return false
        }
        
    }
    
    private func InviteWay(friend: String) {
        
        if hasRefuse(friend: friend) {
            let fetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "inviteName == %@ and eventId == %@ and status == %@", friend, event.eventId! as CVarArg , "拒绝")
            do {
                if let event = try viewContext.fetch(fetchRequest).first {
                    event.status = "等待"
                    try viewContext.save()
                }else{
                    print("未找到符合条件的对象")
                }
            } catch {
                print("更新失败: \(error)")
            }
        }
        else{
            let part = Participant(context: viewContext)
            part.eventName = event.eventName
            part.createName = event.createUser ?? ""
            part.inviteName = friend
            part.startTime = event.startTime
            part.endTime = event.endTime
            part.eventInfo = event.eventInfo
            part.location = event.location
            part.budget = event.budget
            part.type = event.type
            part.status = "等待"
            part.partId = UUID()
            part.eventId = event.eventId
            do {
                try viewContext.save()
                print("邀请发送成功成功")
            } catch {
                let nsError = error as NSError
                fatalError("发生错误 \(nsError), \(nsError.userInfo)")
            }
        }
        
    }
    
    private func hasRefuse(friend: String) -> Bool{
        
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = Participant.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "inviteName == %@ and eventId == %@ and status == %@", friend, event.eventId! as CVarArg , "拒绝")
        fetchRequest.includesSubentities = false
        
        do {
            let count = try viewContext.count(for: fetchRequest)
            return count>0
        } catch {
            print("不存在: \(error)")
            return false
        }
        
    }
    
    
}

//#Preview {
//    InviteFriendsView()
//}
