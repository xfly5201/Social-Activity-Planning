//
//  MyEventView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/5.
//

import SwiftUI
import Combine
import MapKit
import CoreData

enum AlertTypeMyEvent: Identifiable {
    case success, failure
    var id: Int {
        hashValue
    }
}

// 我创建的活动
struct MyEventView: View {
    let event: Event
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var erroInfo: String = ""
    @State private var InfoCopy: String = ""
    
    @State private var alertType: AlertTypeMyEvent?
    
    @State private var isEditing = false

    @State private var eventName: String = ""
    
    @State private var type: String = "线上"
    let eventTypes = ["线上", "线下"]
    
    @State private var type2: String = "公开"
    let eventTypes2 = ["公开", "私密"]
    
    @State private var startTime: Date = Date()
    @State private var endTime: Date = Date()
    
    @State private var location: String = ""
    @StateObject private var locationManager = LocationManager()
    @State private var showMapView = false
    @State private var selectedLocation = CLLocationCoordinate2D()
    
    @State private var budget: Double = 0
    
    let budgetRanges = ["0-100", "100-500", "500-1000"]
        var budgetRangeValues: [String: (Double, Double)] = [
            "0-100": (0, 100),
            "100-500": (100, 500),
            "500-1000": (500, 1000)
        ]
    @State private var selectedBudgetRange: String = "0-100"
    
    @State private var eventInfo: String = "活动详情"
    @State private var keyboardHeight: CGFloat = 0
    @FocusState private var isEditorFocused: Bool
    
    @State private var inviteFriend: Bool = false
    @State private var showFriend: Bool = false
    
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .short
        return formatter
    }()
   
    var body: some View {
        VStack {
            ScrollView{
                
                HStack{
                    Text("活动名称:")
                    if isEditing {
                        TextField("输入活动名称", text: $eventName)
                    } else {
                        Spacer()
                        Text(event.eventName ?? "未知活动")
                    }
                }.padding()
                    .padding(.top,100)
                
                HStack{
                    Text("活动类型:")
                    if isEditing {
                        Picker("选择活动类型", selection: $type) {
                            ForEach(eventTypes, id: \.self) { event in
                                Text(event)
                                    .tag(event)
                            }
                        }
                        .pickerStyle(.segmented)
                    } else {
                        Spacer()
                        Text(event.type ?? "未知类型")
                    }
                }.padding()
                
                
                HStack{
                    if isEditing {
                        VStack(alignment: .leading) {
                            DatePicker("开始时间:", selection: $startTime, displayedComponents: [.date, .hourAndMinute])
                            DatePicker("结束时间:", selection: $endTime, displayedComponents: [.date, .hourAndMinute])
                        }
                        .padding()
                        .onReceive(Just(startTime)) { _ in
                            if startTime >= endTime {
                                endTime = startTime.addingTimeInterval(60)
                            }
                        }
                        .onReceive(Just(endTime)) { _ in
                            if endTime <= startTime {
                                startTime = endTime.addingTimeInterval(-60)
                            }
                        }
                    }
                    else{
                        VStack{
                            HStack{
                                Text("开始时间:")
                                Spacer()
                                if let startTime = event.startTime {
                                    Text(dateFormatter.string(from: startTime))
                                } else {
                                    Text("null")
                                }
                            }.padding(.vertical)
                            
                            HStack{
                                Text("结束时间:")
                                Spacer()
                                if let endTime = event.endTime {
                                    Text(dateFormatter.string(from: endTime))
                                } else {
                                    Text("null")
                                }
                            }
                            
                        }.padding()
                    }
                    
                }
                
                HStack{
                    if isEditing {
                        VStack{
                            HStack{
                                Text("活动地点:")
                                Spacer()
                                Button(action: {
                                    locationManager.requestPermission()
                                    locationManager.getLocation()
                                    showMapView = true
                                }, label: {
                                    Text("选择地点")
                                    Image(systemName: "map")
                                })
                                .sheet(isPresented: $showMapView) {
                                    VStack {
                                        MapView(selectedLocation: $selectedLocation, selectedLocationString: $location, locationManager: locationManager)
                                        Text("选中的地点: \(location)")
                                            .padding()
                                    }
                                }
                            }
                            HStack{
                                Text("活动地点:  \(location)")
                                Spacer()
                            }.padding(.top)
                            
                        }
                    } else {
                        Text("活动地点:")
                        Spacer()
                        Text(event.location ?? "未知地点")
                    }
                }.padding()
                
                
                HStack{
                    if isEditing {
                        VStack(alignment: .leading) {
                            Text("活动经费: \(budget, specifier: "%.2f")")
                            
                            Picker("选择经费区间", selection: $selectedBudgetRange) {
                                ForEach(budgetRanges, id: \.self) { range in
                                    Text(range).tag(range)
                                }
                            }
                            .pickerStyle(.segmented)
                            .padding()
                            
                            Slider(value: $budget, in: budgetRangeValues[selectedBudgetRange]!.0...budgetRangeValues[selectedBudgetRange]!.1, step: 1)
                                .padding(.horizontal)
                        }
                    } else {
                        Text("活动经费: ")
                        Spacer()
                        Text(String(format: "%.2f", event.budget))
                    }
                }.padding()
                
                
                HStack{
                    if isEditing {
                        VStack(alignment: .leading) {
                            Text("活动详情:")
                                .font(.headline)
                                .padding(.top)
                            ScrollView {
                                TextEditor(text: $eventInfo)
                                    .frame(minHeight: 150, maxHeight: 150) // 设置固定高度
                                    .padding(.horizontal)
                                    .background(Color.white)
                                    .cornerRadius(20)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color.gray, lineWidth: 1)
                                    )
                                    .addDoneButtonToKeyboard() // 加入完成按键
                                    .focused($isEditorFocused)
                            }
                        }
                        
                    } else {
                        Text("活动详情:")
                        Spacer()
                        Text(event.eventInfo ?? "无详情")
                    }
                }.padding()
                
                
                HStack{
                    if isEditing {
                        Picker("活动公开", selection: $type2) {
                            ForEach(eventTypes2, id: \.self) { event in
                                Text(event)
                                    .tag(event)
                            }
                        }
                        .pickerStyle(.segmented)
                    } else {
                        Text("范围:")
                        Spacer()
                        Text(event.view ?? "未知类型")
                    }
                }.padding()
                
                
                Button(action: {
                    showFriend.toggle()
                }, label: {
                    Image(systemName: "person.circle")
                })
                .padding()
                .sheet(isPresented: $showFriend) {
                    PersonJoinView(event: event)
                }
                
                
                Button(action: {
                    isEditing.toggle()
                    
                    if !isEditing {
                        saveChange()
                    }
                    InfoCopy=erroInfo
                    erroInfo=""
                }, label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.blue)
                            .frame(width: 300, height: 50)
                        Text(isEditing ? "保存" : "编辑")
                            .foregroundColor(.white)
                        Spacer()
                    }
                })
                .padding()
                .alert(item: $alertType) { alertType in
                    switch alertType {
                    case .success:
                        return Alert(title: Text("修改成功"), message: Text("可以在活动管理看到你的活动"), dismissButton: .default(Text("好")))
                    case .failure:
                        return Alert(title: Text("修改失败"), message: Text(InfoCopy), dismissButton: .default(Text("好")))
                    }
                }
                
                
                Button(action: {
                    inviteFriend.toggle()
                }, label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.green)
                            .frame(width: 300, height: 50)
                        Text("邀请好友")
                            .foregroundColor(.white)
                        Spacer()
                    }
                })
                .padding()
                .sheet(isPresented: $inviteFriend) {
                    InviteFriendsView(event: event)
                }
                
            }
            
            .offset(y: isEditorFocused && keyboardHeight > 0 ? -keyboardHeight : 0)
            .animation(.easeOut(duration: 0.3), value: keyboardHeight)
            .onAppear {
                locationManager.requestPermission()
                locationManager.getLocation()
                
                NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: .main) { notification in
                    guard let keyboardFrame = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else { return }
                    keyboardHeight = keyboardFrame.height
                }

                NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: .main) { _ in keyboardHeight = 0
                }
                
            }
            
        }
        .ignoresSafeArea()
        .onAppear {
            eventName = event.eventName ?? "未知活动"
            eventInfo = event.eventInfo ?? "无详情"
            location = event.location ?? "未知地点"
            budget = event.budget
            type = event.type ?? "线上"
            type2 = event.view ?? ""
        }
    }
    
    private func saveChange() {
        print("尝试修改活动")
        if isSave() {
            print("通过验证，准备修改")
            alertType = .success
            erroInfo=""
            updateMyevent()
            uptadeParticipant()
            do {
                try viewContext.save()
                print("活动修改成功")
            } catch {
                let nsError = error as NSError
                fatalError("发生错误 \(nsError), \(nsError.userInfo)")
            }
        }else{
            alertType = .failure
        }
    }
    
    private func isSave() -> Bool {
        
        
        var flag=true
        if eventName=="" {
            flag=false
            erroInfo += "活动名称不能为空 "
        }
        if location=="" {
            flag=false
            erroInfo += "活动地址不能为空 "
        }
        return flag
    }
    
    private func updateMyevent(){
        
        let fetchRequest: NSFetchRequest<Event> = Event.fetchRequest()
                
        fetchRequest.predicate = NSPredicate(format: "eventId == %@", event.eventId! as CVarArg)
                
        do {
           
            if let event = try viewContext.fetch(fetchRequest).first {
                // 更新对象的属性
                event.eventName = eventName
                event.budget = budget
                event.eventInfo = eventInfo
                event.location = location
                event.startTime = startTime
                event.endTime = endTime
                event.type = type
                event.view = type2
                try viewContext.save()
            }else{
                print("未找到符合条件的对象")
            }
                    
        } catch {
            print("更新失败: \(error)")
        }
    }
    
    private func uptadeParticipant() {
        let fetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
                
        fetchRequest.predicate = NSPredicate(format: "eventId == %@", event.eventId! as CVarArg)
                
        do {
            let events = try viewContext.fetch(fetchRequest)
            for event in events {
                // 更新对象的属性
                event.eventName = eventName
                event.budget = budget
                event.eventInfo = eventInfo
                event.location = location
                event.startTime = startTime
                event.endTime = endTime
                event.type = type
            }
            try viewContext.save()
        } catch {
            print("更新失败: \(error)")
        }
    }
}

//#Preview {
//    MyEventView()
//}
