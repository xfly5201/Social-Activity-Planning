//
//  pendingEventView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/7.
//

import SwiftUI
import CoreData

// 待处理的活动
struct PendingEventView: View {
    
    let event: Participant
    @Binding  var refreshManager: Bool
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var isAgree = false
    @State private var isRefuse = false
    
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .short
        return formatter
    }()
    
    var body: some View {
        VStack {
            ScrollView{
                HStack{
                    Text("活动创建人:")
                    Spacer()
                    Text(event.createName ?? "未知人")
                    
                }.padding()
                
                HStack{
                    Text("活动名称:")
                    Spacer()
                    Text(event.eventName ?? "未知活动")
                    
                }.padding()
                
                HStack{
                    Text("活动类型:")
                    Spacer()
                    Text(event.type ?? "未知类型")
                }.padding()
                
                HStack{
                    Text("活动开始时间:")
                    Spacer()
                    if let startTime = event.startTime {
                        Text(dateFormatter.string(from: startTime))
                    } else {
                        Text("null")
                    }
                }.padding()
                
                HStack{
                    Text("活动结束时间:")
                    Spacer()
                    if let endTime = event.endTime {
                        Text(dateFormatter.string(from: endTime))
                    } else {
                        Text("null")
                    }
                }.padding()
                
                HStack{
                    Text("活动地点:")
                    Spacer()
                    Text(event.location ?? "未知地点")
                }.padding()
                
                HStack{
                    Text("活动经费:")
                    Spacer()
                    Text(String(format: "%.2f", event.budget))
                }.padding()
                
                HStack{
                    Text("活动详情:")
                    Spacer()
                    Text(event.eventInfo ?? "无详情")
                }.padding()
                
                HStack{
                    Text("邀请状态:")
                    Spacer()
                    Text(event.status ?? "无状态")
                }.padding()
                
                
                Button(action: {
                    accept()
                    isAgree.toggle()
                    refreshManager.toggle() // 触发刷新状态
                }, label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.green)
                            .frame(width: 300, height: 50)
                        Text("接受")
                            .foregroundColor(.white)
                        Spacer()
                    }
                })
                .padding()
                .alert(isPresented: $isAgree, content: {
                    Alert(title: Text("已接受该活动"), message: Text("可在活动管理中查看"), dismissButton: .default(Text("好")))
                })
                
                
                
                Button(action: {
                    refuse()
                    isRefuse.toggle()
                    refreshManager.toggle() // 触发刷新状态
                }, label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 50)
                            .fill(Color.red)
                            .frame(width: 300, height: 50)
                        Text("拒绝")
                            .foregroundColor(.white)
                        Spacer()
                    }
                })
                .padding()
                .alert(isPresented: $isRefuse, content: {
                    Alert(title: Text("已拒绝该活动"), message: Text("可在活动管理中查看"), dismissButton: .default(Text("好")))
                })
                
            }
            
            
            
        }
        .font(.headline)
    }
    
    private func accept() {
        
        let fetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
                
        fetchRequest.predicate = NSPredicate(format: "partId == %@", event.partId! as CVarArg)
                
        do {
           
            if let event = try viewContext.fetch(fetchRequest).first {
                event.status = "接受"
                try viewContext.save()
            }else{
                print("未找到符合条件的对象")
            }
                    
        } catch {
            print("更新失败: \(error)")
        }
        
    }
    
    private func refuse(){
        
        let fetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
                
        fetchRequest.predicate = NSPredicate(format: "partId == %@", event.partId! as CVarArg)
                
        do {
           
            if let event = try viewContext.fetch(fetchRequest).first {
                event.status = "拒绝"
                try viewContext.save()
            }else{
                print("未找到符合条件的对象")
            }
                    
        } catch {
            print("更新失败: \(error)")
        }
    }
}




//
//#Preview {
//    pendingEventView()
//}
