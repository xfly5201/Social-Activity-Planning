//
//  TestView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/11/30.
//

import SwiftUI

struct TestView: View {
     

    var body: some View {
        VStack {
            
            ScrollView{
                
                HStack{
                    Text("活动名称:")
                    
                }.padding()
                
                HStack{
                    Text("活动类型:")
                    
                }.padding()
                
                HStack{
                    Text("活动开始时间:")
                    
                }.padding()
                
                HStack{
                    Text("活动结束时间:")
                    
                }.padding()
                
                HStack{
                    Text("活动地点:")
                    
                }.padding()
                
                HStack{
                    Text("活动经费:")
                    
                }.padding()
                
                HStack{
                    Text("活动详情:")
                    
                }.padding()
                
            }
            .font(.headline)
        }
    }
}


#Preview {
    TestView()
}
