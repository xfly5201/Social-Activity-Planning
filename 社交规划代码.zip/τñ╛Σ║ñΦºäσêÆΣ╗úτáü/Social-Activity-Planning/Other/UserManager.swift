//
//  UserManager.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/1.
//

//import SwiftUI
//import CoreData
//
//class UserManager: ObservableObject {
//    @Published var currentUser: User?
//    private var viewContext: NSManagedObjectContext
//
//    init(context: NSManagedObjectContext) {
//        self.viewContext = context
//        // 移除了 checkIfLoggedIn() 的调用
//    }
//
//    func login(user: User) {
//        self.currentUser = user
//        UserDefaults.standard.set(user.userId, forKey: "loggedInUserId")
//    }
//
//    func logout() {
//        self.currentUser = nil
//        UserDefaults.standard.removeObject(forKey: "loggedInUserId")
//    }
//
//    func checkIfLoggedIn() {
//        if let userId = UserDefaults.standard.object(forKey: "loggedInUserId") as? UUID,
//           let user = fetchUser(withId: userId) {
//            self.currentUser = user
//        }
//    }
//
//    private func fetchUser(withId userId: UUID) -> User? {
//        let request: NSFetchRequest<User> = User.fetchRequest()
//        request.predicate = NSPredicate(format: "userId == %@", userId as CVarArg)
//        request.fetchLimit = 1
//
//        do {
//            let users = try viewContext.fetch(request)
//            return users.first
//        } catch {
//            print("Error fetching user: \(error)")
//            return nil
//        }
//    }
//}

