//
//  DataShowView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/1.
//

import SwiftUI

struct DataShowView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest<Participant>(
        sortDescriptors: [
            NSSortDescriptor(keyPath: \Participant.partId, ascending: true),
        ]
    )var events
    
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .short
        return formatter
    }()
    
    var body: some View {
        VStack{
            Text("hello")
            
            List(events, id: \.self) { event in
                HStack {
                    Text(event.eventId?.uuidString ?? "fa")
                    Text(event.eventName ?? "null")
                    
                    if let startTime = event.startTime {
                        Text(dateFormatter.string(from: startTime))
                    } else {
                        Text("null")
                    }

                    if let endTime = event.endTime {
                        Text(dateFormatter.string(from: endTime))
                    } else {
                        Text("null")
                    }

                    Text(event.location ?? "null")
                }
            }
        }
    }
    
}

#Preview {
    DataShowView()
}
