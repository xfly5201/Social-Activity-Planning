//
//  ContentView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/11/30.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) var viewContext
    @EnvironmentObject var coreDataStack: CoreDataStack

    var body: some View {
        if let userIdString = UserDefaults.standard.string(forKey: "loggedInUserId"),
           let userId = UUID(uuidString: userIdString),
           let user = fetchUser1(withId: userId) {
            MainView(user: user)
        } else if let admIdString = UserDefaults.standard.string(forKey: "loggedInAdmId"),
                  let admId = UUID(uuidString: admIdString),
                  let adm = fetchUser2(withId: admId) {
            AdmMainView(adm: adm)
        } else {
            LoginView()
        }
    }

    private func fetchUser1(withId userId: UUID) -> User? {
        let request: NSFetchRequest<User> = User.fetchRequest()
        request.predicate = NSPredicate(format: "userId == %@", userId as CVarArg)
        request.fetchLimit = 1

        do {
            let users = try viewContext.fetch(request)
            return users.first
        } catch {
            print("Error fetching user: \(error)")
            return nil
        }
    }

    private func fetchUser2(withId admId: UUID) -> Admin? {
        let request: NSFetchRequest<Admin> = Admin.fetchRequest()
        request.predicate = NSPredicate(format: "admId == %@", admId as CVarArg)
        request.fetchLimit = 1

        do {
            let users = try viewContext.fetch(request)
            return users.first
        } catch {
            print("Error fetching admin: \(error)")
            return nil
        }
    }
}

#Preview {
    ContentView()
}
