//
//  Social_Activity_PlanningApp.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/11/30.
//

import SwiftUI

@main
struct Social_Activity_PlanningApp: App {
    private let coreDataStack = CoreDataStack(modelName: "SocialPlanModel")
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                // 使得ContentView以及他的子视图都可以从环境里面获取访问数据库的入口
                .environment(\.managedObjectContext,coreDataStack.managedObjectContext) // 添加环境变量
                // 加入环境变量，让所有的子界面都可以调用这个coreDataStack
                .environmentObject(coreDataStack)
        }
    }
}
 
