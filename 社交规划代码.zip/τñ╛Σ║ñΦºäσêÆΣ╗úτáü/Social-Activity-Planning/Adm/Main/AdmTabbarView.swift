//
//  AdmTabbarView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/10.
//

import SwiftUI

enum SelectionTabbarAdm{
    case set
    case manage
    case account
}

struct AdmTabbarView: View {
    
    @Binding var select: SelectionTabbarAdm
    var body: some View {
        HStack{
            Spacer()

            Button{
                select = .set
            }label: {
                Text("发起活动")
            }
            .foregroundColor(select == .set ? .black : .gray)
            Spacer()


            Button{
                select = .manage
            }label: {
                Text("活动管理")
            }
            .foregroundColor(select == .manage ? .black : .gray)
            Spacer()

            Button{
                select = .account
            }label: {
                Text("我的")
            }
            .foregroundColor(select == .account ? .black : .gray)
            Spacer()

        }
        .padding(.top)
        .background(.white)
    }
}

//#Preview {
//    AdmTabbarView()
//}
