//
//  MainAdmView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/10.
//

import SwiftUI

struct AdmMainView: View {
    
    var adm: Admin?
    @State var selectedTab: SelectionTabbarAdm = .set
    var body: some View {
        
        NavigationView {
            VStack {
            
                switch selectedTab {
                case .set:
                    AdmSetView(adm: adm)
                case .manage:
                    AdmManagerView(adm: adm)
                case .account:
                    AdmAccountView(adm: adm)
                }

                AdmTabbarView(select: $selectedTab)
                    .padding(.bottom,40)
            }
            .navigationBarHidden(true)
            .edgesIgnoringSafeArea(.bottom) // 忽略安全区域
        }
        .navigationBarBackButtonHidden(true)
    }
}

//#Preview {
//    MainAdmView()
//}
