//
//  AdmAccountView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/10.
//

import SwiftUI

struct AdmAccountView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    var adm: Admin?
    
    @State private var isLoggedIn: Bool = true
    @State private var isLoggedOut: Bool = false
    @State private var showAlert: Bool = false
    
    
    var body: some View {
        ZStack {
            Color.white.opacity(0.2).edgesIgnoringSafeArea(.all)
            VStack {
                // 退出登录
                Button("退出登录") {
                    // 清除用户ID
                    UserDefaults.standard.removeObject(forKey: "loggedInAdmId")
                    // 更新登录状态
                    isLoggedIn = false
                    showAlert = true
                }
                .alert(isPresented: $showAlert) {
                    Alert(
                        title: Text("成功退出"),
                        message: Text("请重新登录"),
                        dismissButton: .default(Text("好")) {
                            isLoggedOut = true // 当警告关闭时设置 isLoggedOut 为 true
                        }
                    )
                }
            }
            
            // 根据登录状态导航回登录页面
            if isLoggedOut {
                NavigationLink(destination: LoginView(), isActive: $isLoggedOut) {
                    EmptyView()
                }
            }
            
        }
        .ignoresSafeArea()
    }
}

    

//#Preview {
//    AdmAccountView()
//}
