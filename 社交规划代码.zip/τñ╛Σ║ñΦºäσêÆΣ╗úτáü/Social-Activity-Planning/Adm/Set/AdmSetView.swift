//
//  AdmSetView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/10.
//

import SwiftUI

import SwiftUI
import Combine
import MapKit

enum AlertTypeSetAdm: Identifiable {
    case success, failure
    var id: Int {
        hashValue
    }
}

// 活动创建
struct AdmSetView: View {
    
    var adm: Admin?
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var alertType: AlertTypeSetAdm?
    
    @State private var erroInfo: String = ""
    @State private var InfoCopy: String = ""
    
    @State private var eventName: String = ""
    @State private var eventInfo: String = ""
    
    @State private var budget: Double = 0
    let budgetRanges = ["0-100", "100-500", "500-1000"]
        var budgetRangeValues: [String: (Double, Double)] = [
            "0-100": (0, 100),
            "100-500": (100, 500),
            "500-1000": (500, 1000)
        ]
    @State private var selectedBudgetRange: String = "0-100"
    
    @State private var startTime: Date = Date()
    @State private var endTime: Date = Date().addingTimeInterval(60)
    
    @State private var location: String = ""
    @StateObject private var locationManager = LocationManager()
    @State private var showMapView = false
    @State private var selectedLocation = CLLocationCoordinate2D()
    
    @State private var type: String = "线上"
    let eventTypes = ["线上", "线下"]
    
   
    @State private var keyboardHeight: CGFloat = 0
    @FocusState private var isEditorFocused: Bool
    
    
    var body: some View {
        ZStack {
            Color.gray.opacity(0.2).edgesIgnoringSafeArea(.all)
            VStack {
                Text("发起活动")
                    .foregroundColor(.black)
                    .fontWeight(.bold)
                    .padding()
                ScrollView {
                    HStack{
                        Text("活动名称:")
                        TextField("请输入活动名称", text: $eventName)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.leading,5)
                        
                    }.padding()
                    
                    VStack(alignment: .leading) {
                        DatePicker("开始时间:", selection: $startTime, displayedComponents: [.date, .hourAndMinute])
                        DatePicker("结束时间:", selection: $endTime, displayedComponents: [.date, .hourAndMinute])
                    }
                    .padding()
                    .onReceive(Just(startTime)) { _ in
                        if startTime >= endTime {
                            // 调整结束时间为开始时间之后
                            endTime = startTime.addingTimeInterval(60)
                        }
                    }
                    .onReceive(Just(endTime)) { _ in
                        if endTime <= startTime {
                            // 调整开始时间为结束时间之前
                            startTime = endTime.addingTimeInterval(-60)
                        }
                    }
                    
                    
                    VStack{
                        HStack{
                            Text("活动地点:")
                                .padding(.horizontal)
                            Spacer()
                            
                            Button(action: {
                                locationManager.requestPermission()
                                locationManager.getLocation()
                                showMapView = true
                            }, label: {
                                Text("选择地点")
                                Image(systemName: "map")
                            })
                            .sheet(isPresented: $showMapView) {
                                VStack {
                                    MapView(selectedLocation: $selectedLocation, selectedLocationString: $location, locationManager: locationManager)
                                    Text("选中的地点: \(location)")
                                        .padding()
                                }
                            }
                            .padding(.horizontal)
                            
                            
                        }
                        HStack{
                            Text("选择的地点是:  \(location)")
                            Spacer()
                        }
                        .padding()
                        
                    }
                    
                    HStack{
                        Text("活动类型")
                            .padding(.leading)
                        Picker("选择活动类型", selection: $type) {
                            ForEach(eventTypes, id: \.self) { event in
                                Text(event)
                                    .tag(event)
                            }
                        }
                        .pickerStyle(.segmented)
                        
                    }
                    
                    // 经费滑动条
                    VStack(alignment: .leading) {
                        Text("活动经费: \(budget, specifier: "%.2f")")
                        
                        Picker("选择经费区间", selection: $selectedBudgetRange) {
                            ForEach(budgetRanges, id: \.self) { range in
                                Text(range).tag(range)
                            }
                        }
                        .pickerStyle(.segmented)
                        .padding()
                        
                        Slider(value: $budget, in: budgetRangeValues[selectedBudgetRange]!.0...budgetRangeValues[selectedBudgetRange]!.1, step: 1)
                            .padding(.horizontal)
                    }
                    .padding()
                    
                    
                    VStack(alignment: .leading) {
                        Text("活动详情")
                            .font(.headline)
                            .padding(.top)
                        ScrollView {
                            TextEditor(text: $eventInfo)
                                .frame(minHeight: 150, maxHeight: 150) // 设置固定高度
                                .padding(.horizontal)
                                .background(Color.white)
                                .cornerRadius(20)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                                .addDoneButtonToKeyboard() // 加入完成按键
                                .focused($isEditorFocused)
                        }
                    }
                    .padding()
                    
                    
                    Button(action: {
                        setEvent()
                        InfoCopy=erroInfo
                        erroInfo=""
                    }, label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 50)
                                .fill(Color.green)
                                .frame(width: 300, height: 50)
                            Text("创建活动")
                                .foregroundColor(.white)
                            Spacer()
                        }
                    })
                    .padding()
                    .alert(item: $alertType) { alertType in
                        switch alertType {
                        case .success:
                            return Alert(title: Text("创建成功"), message: Text("可以在活动管理看到你的活动"), dismissButton: .default(Text("好")))
                        case .failure:
                            return Alert(title: Text("创建失败"), message: Text(InfoCopy), dismissButton: .default(Text("好")))
                        }
                    }
                    
                }
                // 键盘高度的整体偏移量
                .offset(y: isEditorFocused && keyboardHeight > 0 ? -keyboardHeight : 0)
                // 平滑动画效果
                .animation(.easeOut(duration: 0.3), value: keyboardHeight)
                .onAppear {
                    locationManager.requestPermission() // 请求权限
                    locationManager.getLocation() // 然后获取位置
                    
                    // 移动防止键盘遮挡
                    NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: .main) { notification in
                        guard let keyboardFrame = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else { return }
                        keyboardHeight = keyboardFrame.height
                    }

                    NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: .main) { _ in keyboardHeight = 0
                    }
                    
                }
                
            }
        }
    }
    
    
    // 键盘隐藏
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    private func setEvent() {
        print("尝试添加活动")
        if isSet() {
            print("通过验证，准备添加")
            alertType = .success
            erroInfo=""
            
            let event = Event(context: viewContext)
            event.eventId = UUID()
            event.eventName = eventName
            event.createUser = "官方"  //管理员创建活动
            event.startTime = startTime
            event.endTime = endTime
            event.eventInfo = eventInfo
            event.location = location
            event.budget = budget
            event.type = type
            
            do {
                try viewContext.save()
                print("活动添加成功")
            } catch {
                let nsError = error as NSError
                fatalError("发生错误 \(nsError), \(nsError.userInfo)")
            }
        }else{
            alertType = .failure
        }
    }
    
    private func isSet() -> Bool {
        
        print("开始建立活动")
        
        var flag=true
        if eventName=="" {
            flag=false
            erroInfo += "活动名称不能为空 "
        }
        if location=="" {
            flag=false
            erroInfo += "活动地址不能为空 "
        }
        return flag
    }
    
}

//#Preview {
//    AdmSetView()
//}
