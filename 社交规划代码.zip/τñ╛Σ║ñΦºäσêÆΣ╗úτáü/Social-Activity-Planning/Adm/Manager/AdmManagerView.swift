//
//  AdmManager.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/10.
//

import SwiftUI
import CoreData
import Combine

struct AdmManagerView: View {
    
    var adm: Admin?
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var isRefreshing = false // 刷新状态
    
    // 用户的活动
    @State private var userEvents: [Event] = []
    // 官方的活动
    @State private var admEvents: [Event] = []
    
    
    
    var body: some View {
            ZStack {
                Color.gray.opacity(0.2).edgesIgnoringSafeArea(.all)
                NavigationView {
                    List {
                        Section(header: Text("用户活动").foregroundColor(.black).font(.title).fontWeight(.bold).padding()) {
    
                            ForEach(userEvents) { event in
                                NavigationLink(destination: AdmUserEventView(event: event)) {
                                    HStack {
                                        Text(event.eventName ?? "")
                                            .foregroundColor(.black)
                                            .font(.headline)
                                        Spacer()
                                        Text(event.createUser ?? "")
                                            .foregroundColor(.black)
                                            .font(.headline)
                                    }
                                }
                            }
                            
                        }
                        
                        Section(header: Text("官方活动").foregroundColor(.black).font(.title).fontWeight(.bold).padding()) {
                            ForEach(admEvents) { event in
                                NavigationLink(destination: AdmUserEventView(event: event)) {
                                    HStack {
                                        Text(event.eventName ?? "")
                                            .foregroundColor(.black)
                                            .font(.headline)
                                        Spacer()
                                    }
                                }
                            }
                            .onDelete(perform: deleteAdmEvents)
                        }
                    }
                    .foregroundColor(.black)
                    .navigationBarTitle("活动管理", displayMode: .inline)
                }
                .onAppear {
                    fetchData()
                }
                .onReceive(Just(isRefreshing)) { _ in
                    fetchData()
                }
            }
        }

    private func deleteAdmEvents(at offsets: IndexSet) {
        for index in offsets {
            let event = admEvents[index]
            deletePart(event: event)
            viewContext.delete(event)
        }

        do {
            try viewContext.save()
            isRefreshing.toggle()
        } catch {
            print("保存失败: \(error)")
        }
    }

    
    // 获取数据
    private func fetchData() {
        // 更新 userEvents
        let userEventsFetchRequest: NSFetchRequest<Event> = Event.fetchRequest()
        userEventsFetchRequest.predicate = NSPredicate(format: "createUser != %@", "官方")
        userEventsFetchRequest.includesSubentities = false
        
        do {
            userEvents = try viewContext.fetch(userEventsFetchRequest)
        } catch {
            print("用户创建活动查询失败: \(error)")
            userEvents = []
        }
        
        // 更新 admEvents
        let admEventsFetchRequest: NSFetchRequest<Event> = Event.fetchRequest()
        admEventsFetchRequest.predicate = NSPredicate(format: "createUser == %@", "官方")
        admEventsFetchRequest.includesSubentities = false
        
        do {
            admEvents = try viewContext.fetch(admEventsFetchRequest)
        } catch {
            print("用户接受活动查询失败: \(error)")
            admEvents = []
        }
    }
    
    
    private func deletePart(event: Event){
        
        let fetchRequest: NSFetchRequest<Participant> = Participant.fetchRequest()
                
        fetchRequest.predicate = NSPredicate(format: "eventId == %@", event.eventId! as CVarArg)
                
        do {
            let events = try viewContext.fetch(fetchRequest)
            for event in events {
                viewContext.delete(event)
            }
            try viewContext.save()
        } catch {
            print("更新失败: \(error)")
        }
    }
    
}

//#Preview {
//    AdmManager()
//}
