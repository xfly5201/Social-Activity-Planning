//
//  KeyboardAdaptive.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/3.
//

import SwiftUI

// 键盘出现完成
struct DoneButtonOnKeyboard: ViewModifier {
    func body(content: Content) -> some View {
        content
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("完成") {
                        hideKeyboard()
                    }
                }
            }
    }
}
extension View {
    func addDoneButtonToKeyboard() -> some View {
        self.modifier(DoneButtonOnKeyboard())
    }
}
func hideKeyboard() {
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
}
