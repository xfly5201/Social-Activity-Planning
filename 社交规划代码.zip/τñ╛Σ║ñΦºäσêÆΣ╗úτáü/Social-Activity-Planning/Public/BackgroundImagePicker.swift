//
//  BackgroundImagePicker.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/8.
//

import Foundation
import UIKit
import SwiftUI

// 选择图片作为背景
struct BackgroundImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.presentationMode) var presentationMode
    var didSelectImage: ((UIImage?) -> Void)?

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        var parent: BackgroundImagePicker

        init(parent: BackgroundImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.editedImage] as? UIImage,
               let userId = UserDefaults.standard.string(forKey: "loggedInUserId") {  // 获取当前登录用户的 userId
                
                let currentImageVersion = UserDefaults.standard.integer(forKey: "user\(userId)BackgroundImageVersion")
                let newImageVersion = currentImageVersion + 1

                parent.image = uiImage

                // 判断是否是新选择的图片
                let isNewImage = newImageVersion != currentImageVersion

                if isNewImage {
                    // 保存新的头像数据和版本号
                    UserDefaults.standard.set(uiImage.pngData(), forKey: "user\(userId)BackgroundImage")
                    UserDefaults.standard.set(newImageVersion, forKey: "user\(userId)BackgroundImageVersion")
                }

                parent.didSelectImage?(uiImage)
            }

            parent.presentationMode.wrappedValue.dismiss()
        }
    }

    var sourceType: UIImagePickerController.SourceType = .photoLibrary

    func makeUIViewController(context: UIViewControllerRepresentableContext<BackgroundImagePicker>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.allowsEditing = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<BackgroundImagePicker>) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
}
