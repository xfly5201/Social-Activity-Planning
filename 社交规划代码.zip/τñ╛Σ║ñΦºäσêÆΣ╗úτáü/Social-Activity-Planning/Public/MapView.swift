//
//  LocationPickerView.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/3.
//

import SwiftUI
import MapKit

// 定义地图
struct MapView: UIViewRepresentable {
    @Binding var selectedLocation: CLLocationCoordinate2D
    @Binding var selectedLocationString: String
    var locationManager: LocationManager

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = true

        
        // 长按手势添加标记
        let longPressGesture = UILongPressGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleLongPress(_:)))
        mapView.addGestureRecognizer(longPressGesture)
        
        
        locationManager.onLocationUpdate = { location in
            let region = MKCoordinateRegion(center: location, latitudinalMeters: 500, longitudinalMeters: 500)
            mapView.setRegion(region, animated: true)
        }

        return mapView
    }

    func updateUIView(_ mapView: MKMapView, context: Context) {
        if let location = locationManager.location {
            let region = MKCoordinateRegion(center: location, latitudinalMeters: 500, longitudinalMeters: 500)
            mapView.setRegion(region, animated: true)
        }
    }


    func makeCoordinator() -> Coordinator {
        Coordinator(self, locationManager: locationManager)
    }

    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: MapView
        var locationManager: LocationManager

        init(_ parent: MapView, locationManager: LocationManager) {
            self.parent = parent
            self.locationManager = locationManager
        }

        @objc func handleLongPress(_ gesture: UILongPressGestureRecognizer) {
            guard gesture.state == .began else { return }
            let point = gesture.location(in: gesture.view)
            let coordinate = (gesture.view as! MKMapView).convert(point, toCoordinateFrom: gesture.view)

            // 更新选中位置
            parent.selectedLocation = coordinate
            parent.locationManager.getPlace(for: coordinate) { placeName in
                DispatchQueue.main.async {
                    self.parent.selectedLocationString = placeName
                }
            }
        }
    }
}









