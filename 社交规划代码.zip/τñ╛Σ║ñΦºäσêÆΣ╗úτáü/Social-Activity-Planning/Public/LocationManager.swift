//
//  LocationManager.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/3.
//

import CoreLocation

// 地点处理
class LocationManager: NSObject, CLLocationManagerDelegate,ObservableObject {
    private let locationManager = CLLocationManager()
    @Published var location: CLLocationCoordinate2D?
    @Published var locationName: String = ""

    var onLocationUpdate: ((CLLocationCoordinate2D) -> Void)?

    override init() {
        super.init()
        locationManager.delegate = self
    }

    func requestPermission() {
        locationManager.requestWhenInUseAuthorization()
    }

    func getLocation() {
        locationManager.requestLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let currentLocation = locations.first?.coordinate {
            location = currentLocation
            onLocationUpdate?(currentLocation)
        }
    }
    

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error getting location: \(error)")
    }

    func getPlace(for location: CLLocationCoordinate2D, completion: @escaping (String) -> Void) {
        let geocoder = CLGeocoder()
        let loc = CLLocation(latitude: location.latitude, longitude: location.longitude)
        geocoder.reverseGeocodeLocation(loc) { (placemarks, error) in
            if let error = error {
                print("Error in reverseGeocodeLocation: \(error)")
                completion("Unknown place")
            } else if let placemarks = placemarks, let placemark = placemarks.first {
                var placeName = placemark.name ?? ""
                if let locality = placemark.locality {
                    placeName += ", \(locality)"
                }
                if let adminArea = placemark.administrativeArea {
                    placeName += ", \(adminArea)"
                }
                completion(placeName)
            }
        }
    }
}

