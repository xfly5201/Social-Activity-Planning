//
//  Coordinator.swift
//  Social-Activity-Planning
//
//  Created by 夏飞宇 on 2023/12/8.
//

import Foundation
import UIKit
import SwiftUI

// 选择图片作为头像
struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.presentationMode) var presentationMode
    var didSelectImage: ((UIImage?) -> Void)?

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        var parent: ImagePicker

        init(parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.editedImage] as? UIImage,
               let userId = UserDefaults.standard.string(forKey: "loggedInUserId") {  // 获取当前登录用户的 userId
                
                let currentImageVersion = UserDefaults.standard.integer(forKey: "user\(userId)ImageVersion")
                let newImageVersion = currentImageVersion + 1

                parent.image = uiImage

                // 判断是否是新选择的图片
                let isNewImage = newImageVersion != currentImageVersion

                if isNewImage {
                    // 保存新的头像数据和版本号
                    UserDefaults.standard.set(uiImage.pngData(), forKey: "user\(userId)Image")
                    UserDefaults.standard.set(newImageVersion, forKey: "user\(userId)ImageVersion")
                }

                parent.didSelectImage?(uiImage)
            }

            parent.presentationMode.wrappedValue.dismiss()
        }
    }

    var sourceType: UIImagePickerController.SourceType = .photoLibrary

    func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.allowsEditing = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<ImagePicker>) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
}
